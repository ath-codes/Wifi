package com.wifi.quality

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View
import java.util.Locale

// رسم بياني بسيط لزمن الاستجابة (الراوتر + الإنترنت)
class Graph(c: Context, private val maxN: Int) : View(c) {
    private var a: List<Int> = emptyList()
    private var b: List<Int> = emptyList()
    private val pa = line(0xFF4CAF50.toInt())
    private val pb = line(0xFF4DA3FF.toInt())
    private val pl = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFF44336.toInt(); strokeWidth = 5f }
    private val pg = Paint().apply { color = 0xFF2C3442.toInt(); strokeWidth = 2f }
    private val pt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF6B7587.toInt(); textSize = 26f }

    private fun line(col: Int) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = col; strokeWidth = 4f; style = Paint.Style.STROKE; strokeJoin = Paint.Join.ROUND
    }

    fun setData(x: List<Int>, y: List<Int>) { a = x; b = y; invalidate() }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        var mx = 100
        for (v in a) if (v > mx) mx = v
        for (v in b) if (v > mx) mx = v
        if (mx > 400) mx = 400
        cv.drawLine(0f, h - 6f, w, h - 6f, pg)
        cv.drawLine(0f, h / 2, w, h / 2, pg)
        cv.drawText("$mx ms", 4f, 24f, pt)
        series(cv, a, pa, w, h, mx)
        series(cv, b, pb, w, h, mx)
    }

    private fun series(cv: Canvas, s: List<Int>, p: Paint, w: Float, h: Float, mx: Int) {
        if (s.isEmpty()) return
        val step = w / (maxN - 1)
        val path = Path()
        var open = false
        for (i in s.indices) {
            val x = w - (s.size - 1 - i) * step
            val v = s[i]
            if (v < 0) {
                cv.drawLine(x, h - 6f, x, h - 40f, pl)
                open = false
                continue
            }
            val y = h - 6f - (minOf(v, mx).toFloat() / mx) * (h - 14f)
            if (!open) { path.moveTo(x, y); open = true } else path.lineTo(x, y)
        }
        cv.drawPath(path, p)
    }
}

// عداد دائري لسرعة التحميل/الرفع
class Gauge(c: Context) : View(c) {
    private var value = 0.0
    private var label = ""
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF2C3442.toInt(); style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND
    }
    private val fg = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val tv = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt(); textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD
    }
    private val tl = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF9AA4B5.toInt(); textAlign = Paint.Align.CENTER }

    fun setValue(v: Double, l: String) { value = v; label = l; invalidate() }

    override fun onDraw(cv: Canvas) {
        val d = resources.displayMetrics.density
        val w = width.toFloat()
        val h = height.toFloat()
        val sw = 12f * d
        bg.strokeWidth = sw
        fg.strokeWidth = sw
        tv.textSize = 34f * d
        tl.textSize = 14f * d
        val r = minOf(w, h) / 2f - sw
        val rect = RectF(w / 2 - r, h / 2 - r, w / 2 + r, h / 2 + r)
        cv.drawArc(rect, 135f, 270f, false, bg)
        val scale = when { value <= 50.0 -> 50.0; value <= 100.0 -> 100.0; value <= 300.0 -> 300.0; else -> 1000.0 }
        fg.color = when {
            value >= 50.0 -> 0xFF4CAF50.toInt()
            value >= 25.0 -> 0xFF8BC34A.toInt()
            value >= 5.0 -> 0xFFFFC107.toInt()
            else -> 0xFFF44336.toInt()
        }
        val sweep = (270.0 * value / scale).coerceIn(0.0, 270.0).toFloat()
        if (sweep > 0f) cv.drawArc(rect, 135f, sweep, false, fg)
        cv.drawText(String.format(Locale.US, "%.1f", value), w / 2, h / 2 + 10f * d, tv)
        cv.drawText("Mbps  $label", w / 2, h / 2 + 36f * d, tl)
    }
}
