package com.wifi.quality

import android.content.Context

class TestEntry(val ts: Long, val room: String, val dl: Double, val ul: Double, val rssi: Int, val ping: Int)
class Outage(val start: Long, val durMs: Long, val cause: String)

fun fmtDur(ms: Long): String {
    val s = ms / 1000
    return when {
        s < 60 -> "$s ثانية"
        s < 3600 -> "${s / 60} د ${s % 60} ث"
        else -> "${s / 3600} س ${(s % 3600) / 60} د"
    }
}

object Store {
    private fun p(c: Context) = c.getSharedPreferences("wq", Context.MODE_PRIVATE)
    private fun clean(s: String) = s.replace(";", " ").replace("\n", " ").trim()

    fun room(c: Context): String = p(c).getString("room", "") ?: ""
    fun setRoom(c: Context, r: String) { p(c).edit().putString("room", clean(r)).apply() }

    fun plan(c: Context): Float = p(c).getFloat("plan", 0f)
    fun setPlan(c: Context, v: Float) { p(c).edit().putFloat("plan", v).apply() }

    fun monitorOn(c: Context): Boolean = p(c).getBoolean("monitor", false)
    fun setMonitorOn(c: Context, v: Boolean) { p(c).edit().putBoolean("monitor", v).apply() }

    @Synchronized
    fun tests(c: Context): List<TestEntry> {
        val raw = p(c).getString("tests", "") ?: ""
        val out = ArrayList<TestEntry>()
        for (ln in raw.split("\n")) {
            val f = ln.split(";")
            if (f.size < 6) continue
            try {
                out.add(TestEntry(f[0].toLong(), f[1], f[2].toDouble(), f[3].toDouble(), f[4].toInt(), f[5].toInt()))
            } catch (e: Exception) { }
        }
        return out
    }

    @Synchronized
    fun addTest(c: Context, e: TestEntry) {
        val list = ArrayList<TestEntry>(tests(c))
        list.add(e)
        while (list.size > 100) list.removeAt(0)
        val txt = list.joinToString("\n") { "${it.ts};${clean(it.room)};${it.dl};${it.ul};${it.rssi};${it.ping}" }
        p(c).edit().putString("tests", txt).apply()
    }

    @Synchronized
    fun outages(c: Context): List<Outage> {
        val raw = p(c).getString("outages", "") ?: ""
        val out = ArrayList<Outage>()
        for (ln in raw.split("\n")) {
            val f = ln.split(";")
            if (f.size < 3) continue
            try { out.add(Outage(f[0].toLong(), f[1].toLong(), f[2])) } catch (e: Exception) { }
        }
        return out
    }

    @Synchronized
    fun addOutage(c: Context, o: Outage) {
        val list = ArrayList<Outage>(outages(c))
        list.add(o)
        while (list.size > 300) list.removeAt(0)
        val txt = list.joinToString("\n") { "${it.start};${it.durMs};${clean(it.cause)}" }
        p(c).edit().putString("outages", txt).apply()
    }

    @Synchronized
    fun clearOutages(c: Context) { p(c).edit().remove("outages").apply() }
}
