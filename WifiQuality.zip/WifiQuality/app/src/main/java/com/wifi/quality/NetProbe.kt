package com.wifi.quality

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.SystemClock
import java.net.ConnectException
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.Socket

object NetProbe {

    // يرجع الزمن بالميلي ثانية، أو -1 عند الفشل. "رفض الاتصال" يُعد استجابة صحيحة (الجهاز ردّ).
    fun tcpPing(host: String, port: Int, timeout: Int): Int {
        val t0 = SystemClock.elapsedRealtime()
        return try {
            Socket().use { it.connect(InetSocketAddress(host, port), timeout) }
            (SystemClock.elapsedRealtime() - t0).toInt()
        } catch (e: ConnectException) {
            if (e.message?.contains("refused", true) == true) (SystemClock.elapsedRealtime() - t0).toInt() else -1
        } catch (e: Exception) {
            -1
        }
    }

    fun pingNet(): Int {
        var r = tcpPing("1.1.1.1", 443, 1500)
        if (r < 0) r = tcpPing("8.8.8.8", 443, 1000)
        return r
    }

    fun onWifi(ctx: Context): Boolean {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val n = cm.activeNetwork ?: return false
        return cm.getNetworkCapabilities(n)?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
    }

    fun findGateway(ctx: Context): String? {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val n = cm.activeNetwork ?: return null
        val caps = cm.getNetworkCapabilities(n) ?: return null
        if (!caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) return null
        val lp = cm.getLinkProperties(n) ?: return null
        for (r in lp.routes) {
            val g = r.gateway
            if (r.isDefaultRoute && g is Inet4Address) return g.hostAddress
        }
        return null
    }
}
