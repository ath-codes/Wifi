package com.wifi.quality

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.SystemClock

// مراقبة في الخلفية: تسجّل الانقطاعات (الوقت والمدة والسبب) وتنبّه عند الانقطاع أو ضعف الإشارة
class MonitorService : Service() {

    @Volatile private var running = false
    private var worker: Thread? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannels()
        val n = Notification.Builder(this, CH_MON)
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentTitle("مراقبة الاتصال تعمل")
            .setContentText("تسجيل الانقطاعات في الخلفية")
            .setContentIntent(openApp())
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(ID_MON, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(ID_MON, n)
        }
        if (!running) {
            running = true
            worker = Thread { loop() }.also { it.start() }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        worker?.interrupt()
        super.onDestroy()
    }

    private fun openApp(): PendingIntent =
        PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)

    private fun createChannels() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH_MON, "المراقبة", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_ALERT, "تنبيهات الاتصال", NotificationManager.IMPORTANCE_HIGH))
    }

    private fun alert(id: Int, title: String, text: String) {
        val n = Notification.Builder(this, CH_ALERT)
            .setSmallIcon(android.R.drawable.stat_notify_error)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(openApp())
            .setAutoCancel(true)
            .build()
        try { (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(id, n) } catch (e: Exception) { }
    }

    private fun classify(): String {
        val g = NetProbe.findGateway(this) ?: return "لا يوجد اتصال وايفاي"
        var r = NetProbe.tcpPing(g, 80, 800)
        if (r < 0) r = NetProbe.tcpPing(g, 53, 400)
        return if (r >= 0) "الإنترنت (من الراوتر أو شركة الإنترنت)" else "الوايفاي أو الراوتر"
    }

    @Suppress("DEPRECATION")
    private fun rssi(): Int {
        val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
        return wm.connectionInfo?.rssi ?: 0
    }

    private fun loop() {
        var fails = 0
        var failStart = 0L
        var outStart = 0L
        var cause = ""
        var weak = 0
        var weakSent = false
        while (running) {
            val t0 = SystemClock.elapsedRealtime()
            try {
                val ms = NetProbe.pingNet()
                val now = System.currentTimeMillis()
                if (ms < 0) {
                    fails++
                    if (fails == 1) failStart = now
                    if (fails == 2 && outStart == 0L) {
                        outStart = failStart
                        cause = classify()
                        alert(ID_ALERT, "انقطع الإنترنت", cause)
                    }
                } else {
                    if (outStart != 0L) {
                        val dur = now - outStart
                        Store.addOutage(this, Outage(outStart, dur, cause))
                        alert(ID_ALERT, "عاد الإنترنت", "بعد " + fmtDur(dur))
                        outStart = 0L
                    }
                    fails = 0
                }
                val r = rssi()
                if (r in -126..-81) {
                    weak++
                    if (weak >= 3 && !weakSent) {
                        weakSent = true
                        alert(ID_WEAK, "الإشارة ضعيفة جدًا", "$r dBm — اقترب من الراوتر")
                    }
                } else {
                    weak = 0
                    if (r > -75) weakSent = false
                }
            } catch (e: Exception) { }
            val rest = 2000 - (SystemClock.elapsedRealtime() - t0)
            if (rest > 0) try { Thread.sleep(rest) } catch (e: InterruptedException) { }
        }
        if (outStart != 0L) {
            Store.addOutage(this, Outage(outStart, System.currentTimeMillis() - outStart, cause))
        }
    }

    companion object {
        const val CH_MON = "mon"
        const val CH_ALERT = "alert"
        const val ID_MON = 1
        const val ID_ALERT = 2
        const val ID_WEAK = 3
    }
}
