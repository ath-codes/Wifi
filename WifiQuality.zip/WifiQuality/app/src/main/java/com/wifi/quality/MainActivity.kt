package com.wifi.quality

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.wifi.WifiManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL
import java.util.Locale
import kotlin.math.abs

class MainActivity : Activity() {

    private class Row(val value: TextView, val note: TextView)

    private val ui = Handler(Looper.getMainLooper())
    private val samples = ArrayDeque<Int>() // -1 = فشل
    @Volatile private var alive = false
    private var worker: Thread? = null

    private lateinit var verdict: TextView
    private lateinit var signal: Row
    private lateinit var ping: Row
    private lateinit var jitter: Row
    private lateinit var loss: Row
    private lateinit var speed: Row
    private lateinit var band: Row
    private lateinit var dl: Row
    @Volatile private var testing = false

    private val colors = intArrayOf(0xFFF44336.toInt(), 0xFFFFC107.toInt(), 0xFF8BC34A.toInt(), 0xFF4CAF50.toInt())

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(16), dp(36), dp(16), dp(16))
        }
        verdict = TextView(this).apply {
            textSize = 28f; typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            setPadding(0, dp(8), 0, dp(20)); text = "…"
        }
        root.addView(verdict)
        signal = row(root, "قوة الإشارة")
        ping = row(root, "سرعة الاستجابة (Ping)")
        jitter = row(root, "الثبات (Jitter)")
        loss = row(root, "فقدان الحزم")
        speed = row(root, "سرعة الربط")
        band = row(root, "النطاق")
        dl = row(root, "سرعة التحميل")
        set(dl, "—", "اضغط الزر للقياس", 1)
        val btn = TextView(this).apply {
            text = "اختبر سرعة التحميل"; textSize = 17f; typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            setPadding(0, dp(14), 0, dp(14))
            background = GradientDrawable().apply { setColor(0xFF2563EB.toInt()); cornerRadius = dp(14).toFloat() }
            setOnClickListener { runSpeedTest(this) }
        }
        root.addView(btn, LinearLayout.LayoutParams(-1, -2))
        setContentView(ScrollView(this).apply {
            setBackgroundColor(0xFF0F131A.toInt()); addView(root)
        })
    }

    private fun row(parent: LinearLayout, title: String): Row {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = GradientDrawable().apply { setColor(0xFF1E2430.toInt()); cornerRadius = dp(14).toFloat() }
        }
        card.addView(TextView(this).apply { text = title; textSize = 13f; setTextColor(0xFF9AA4B5.toInt()) })
        val line = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val v = TextView(this).apply { textSize = 24f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE) }
        val n = TextView(this).apply { textSize = 16f; setPadding(dp(12), 0, 0, 0) }
        line.addView(v); line.addView(n); card.addView(line)
        parent.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        return Row(v, n)
    }

    private fun set(r: Row, value: String, note: String, lv: Int) {
        r.value.text = value
        r.note.text = note
        r.note.setTextColor(colors[lv])
    }

    override fun onStart() {
        super.onStart()
        alive = true
        worker = Thread {
            while (alive) {
                val t0 = SystemClock.elapsedRealtime()
                val ms = try {
                    Socket().use { it.connect(InetSocketAddress("1.1.1.1", 443), 1500) }
                    (SystemClock.elapsedRealtime() - t0).toInt()
                } catch (e: Exception) { -1 }
                ui.post { onSample(ms) }
                val rest = 1000 - (SystemClock.elapsedRealtime() - t0)
                if (rest > 0) try { Thread.sleep(rest) } catch (e: InterruptedException) { }
            }
        }.also { it.start() }
    }

    override fun onStop() {
        super.onStop()
        alive = false
        worker?.interrupt()
    }

    private fun mbps(bytes: Long, ms: Long) = bytes * 8.0 / 1_000_000 / (ms / 1000.0)

    private fun runSpeedTest(btn: TextView) {
        if (testing) return
        testing = true
        btn.text = "جارٍ القياس…"; btn.alpha = 0.6f
        set(dl, "…", "جارٍ القياس", 1)
        Thread {
            var total = 0L
            val t0 = SystemClock.elapsedRealtime()
            var last = t0
            try {
                val c = URL("https://speed.cloudflare.com/__down?bytes=25000000").openConnection() as HttpURLConnection
                c.connectTimeout = 4000; c.readTimeout = 4000
                c.inputStream.use { s ->
                    val buf = ByteArray(32768)
                    while (true) {
                        val n = s.read(buf)
                        if (n < 0) break
                        total += n
                        val now = SystemClock.elapsedRealtime()
                        if (now - last > 500) {
                            last = now
                            val m = mbps(total, now - t0)
                            ui.post { set(dl, String.format(Locale.US, "%.1f Mbps", m), "جارٍ القياس", 1) }
                        }
                        if (now - t0 > 7000) break
                    }
                }
                c.disconnect()
            } catch (e: Exception) { }
            val ms = SystemClock.elapsedRealtime() - t0
            ui.post {
                if (total < 100_000) {
                    set(dl, "—", "فشل القياس — تحقق من الإنترنت", 0)
                } else {
                    val m = mbps(total, ms)
                    val lv = when { m >= 50 -> 3; m >= 25 -> 2; m >= 5 -> 1; else -> 0 }
                    set(dl, String.format(Locale.US, "%.1f Mbps", m),
                        arrayOf("بطيئة", "للتصفح فقط", "جيدة للبث HD", "ممتازة للبث 4K")[lv], lv)
                }
                testing = false
                btn.text = "اختبر سرعة التحميل"; btn.alpha = 1f
            }
        }.start()
    }

    private fun onSample(ms: Int) {
        if (testing) return
        samples.addLast(ms)
        if (samples.size > 10) samples.removeFirst()
        refresh()
    }

    @Suppress("DEPRECATION")
    private fun refresh() {
        val levels = ArrayList<Int>()

        // الوايفاي
        val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
        val info = wm.connectionInfo
        val connected = wm.isWifiEnabled && info != null && info.rssi > -127 && info.networkId != -1
        if (connected) {
            val r = info.rssi
            val ls = when { r >= -50 -> 3; r >= -60 -> 2; r >= -70 -> 1; else -> 0 }
            set(signal, "$r dBm", arrayOf("ضعيفة — اقترب من الراوتر", "متوسطة", "جيدة", "ممتازة")[ls], ls)
            levels.add(ls)

            val s = info.linkSpeed
            val ss = when { s >= 300 -> 3; s >= 100 -> 2; s >= 50 -> 1; else -> 0 }
            set(speed, "$s Mbps", arrayOf("بطيئة", "متوسطة", "جيدة", "سريعة")[ss], ss)

            val f = info.frequency
            val (bn, bs) = when {
                f < 3000 -> "2.4 GHz" to "مدى أبعد، أبطأ"
                f < 5900 -> "5 GHz" to "أسرع، مدى أقصر"
                else -> "6 GHz" to "الأسرع، مدى قصير"
            }
            set(band, bn, bs, if (f < 3000) 1 else 3)
        } else {
            set(signal, "—", "غير متصل بوايفاي", 0)
            set(speed, "—", "", 0)
            set(band, "—", "", 0)
            levels.add(0)
        }

        // Ping / Jitter / Loss
        val ok = samples.filter { it >= 0 }
        val lossPct = (samples.size - ok.size) * 100 / samples.size
        val ls = when { lossPct == 0 -> 3; lossPct <= 10 -> 1; else -> 0 }
        set(loss, "$lossPct%", arrayOf("فقدان كثير", "", "", "لا يوجد فقدان")[ls].ifEmpty { "فقدان بسيط" }, ls)
        levels.add(ls)

        if (ok.isEmpty()) {
            set(ping, "—", "لا يوجد إنترنت", 0)
            set(jitter, "—", "", 0)
            levels.add(0)
        } else {
            val avg = ok.average().toInt()
            val ps = when { avg < 30 -> 3; avg < 60 -> 2; avg < 120 -> 1; else -> 0 }
            set(ping, "$avg ms", arrayOf("بطيء", "متوسط", "جيد للتصفح", "ممتاز للألعاب")[ps], ps)
            levels.add(ps)

            val j = if (ok.size < 2) 0 else ok.zipWithNext { a, c -> abs(a - c) }.average().toInt()
            val js = when { j < 10 -> 3; j < 30 -> 2; else -> 0 }
            set(jitter, "$j ms", arrayOf("متذبذب — المكالمات تتقطع", "", "مقبول", "مستقر")[js].ifEmpty { "" }, js)
            levels.add(js)
        }

        val v = levels.min()
        verdict.text = arrayOf("اتصالك ضعيف", "اتصالك متوسط", "اتصالك جيد", "اتصالك ممتاز")[v]
        verdict.setTextColor(colors[v])
    }
}
