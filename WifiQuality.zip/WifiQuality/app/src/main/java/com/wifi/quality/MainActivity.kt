package com.wifi.quality

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.net.ConnectException
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.abs

class MainActivity : Activity() {

    private class Row(val title: String, val value: TextView, val note: TextView)
    private class St(val avg: Int, val loss: Int, val jit: Int)

    // رسم بياني بسيط لزمن الاستجابة (الراوتر + الإنترنت)
    private class Graph(c: Context, private val maxN: Int) : View(c) {
        private var a: List<Int> = emptyList()
        private var b: List<Int> = emptyList()
        private val pa = line(0xFF4CAF50.toInt())
        private val pb = line(0xFF4DA3FF.toInt())
        private val pl = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFF44336.toInt(); strokeWidth = 5f }
        private val pg = Paint().apply { color = 0xFF2C3442.toInt(); strokeWidth = 2f }
        private val pt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF6B7587.toInt(); textSize = 26f }

        private fun line(col: Int) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = col; strokeWidth = 4f; style = Paint.Style.STROKE; strokeJoin = Paint.Join.ROUND
        }

        fun setData(x: List<Int>, y: List<Int>) { a = x; b = y; invalidate() }

        override fun onDraw(cv: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            var mx = 100
            for (v in a) if (v > mx) mx = v
            for (v in b) if (v > mx) mx = v
            if (mx > 400) mx = 400
            cv.drawLine(0f, h - 6f, w, h - 6f, pg)
            cv.drawLine(0f, h / 2, w, h / 2, pg)
            cv.drawText("$mx ms", 4f, 24f, pt)
            series(cv, a, pa, w, h, mx)
            series(cv, b, pb, w, h, mx)
        }

        private fun series(cv: Canvas, s: List<Int>, p: Paint, w: Float, h: Float, mx: Int) {
            if (s.isEmpty()) return
            val step = w / (maxN - 1)
            val path = Path()
            var open = false
            for (i in s.indices) {
                val x = w - (s.size - 1 - i) * step
                val v = s[i]
                if (v < 0) {
                    cv.drawLine(x, h - 6f, x, h - 40f, pl)
                    open = false
                    continue
                }
                val y = h - 6f - (minOf(v, mx).toFloat() / mx) * (h - 14f)
                if (!open) { path.moveTo(x, y); open = true } else path.lineTo(x, y)
            }
            cv.drawPath(path, p)
        }
    }

    private val ui = Handler(Looper.getMainLooper())
    private val maxN = 80
    private val netG = ArrayDeque<Int>()      // للرسم البياني (-1 = فشل)
    private val gwG = ArrayDeque<Int>()
    private val netS = ArrayDeque<Int>()      // للإحصاءات (آخر 20) — تتجمد أثناء اختبار السرعة
    private val gwS = ArrayDeque<Int>()
    private val dnsS = ArrayDeque<Int>()
    private val loadSamples = ArrayList<Int>() // الاستجابة أثناء التحميل/الرفع
    private var idleAvg = -1

    @Volatile private var alive = false
    @Volatile private var gen = 0
    @Volatile private var gwPort = 80
    @Volatile private var testing = false
    private val threads = ArrayList<Thread>()
    private val rows = ArrayList<Row>()

    private lateinit var verdict: TextView
    private lateinit var diag: TextView
    private lateinit var graph: Graph
    private lateinit var testBtn: TextView
    private lateinit var signal: Row
    private lateinit var speed: Row
    private lateinit var band: Row
    private lateinit var router: Row
    private lateinit var ping: Row
    private lateinit var jitter: Row
    private lateinit var loss: Row
    private lateinit var dns: Row
    private lateinit var dl: Row
    private lateinit var ul: Row
    private lateinit var load: Row

    private val colors = intArrayOf(0xFFF44336.toInt(), 0xFFFFC107.toInt(), 0xFF8BC34A.toInt(), 0xFF4CAF50.toInt())
    private val testLabel = "اختبر السرعة (تحميل + رفع)"

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(16), dp(36), dp(16), dp(16))
        }
        verdict = TextView(this).apply {
            textSize = 28f; typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            setPadding(0, dp(8), 0, dp(6)); text = "…"
        }
        root.addView(verdict)
        diag = TextView(this).apply {
            textSize = 15f; gravity = Gravity.CENTER; setTextColor(0xFF9AA4B5.toInt())
            setPadding(dp(8), 0, dp(8), dp(18)); text = "جارٍ التحليل…"
        }
        root.addView(diag)

        graphCard(root)

        signal = row(root, "قوة الإشارة")
        router = row(root, "الاتصال بالراوتر (داخل البيت)")
        ping = row(root, "الاتصال بالإنترنت (Ping)")
        jitter = row(root, "الثبات (Jitter)")
        loss = row(root, "فقدان الحزم")
        dns = row(root, "سرعة DNS (فتح المواقع)")
        speed = row(root, "سرعة الربط")
        band = row(root, "النطاق")
        dl = row(root, "سرعة التحميل")
        ul = row(root, "سرعة الرفع")
        load = row(root, "الاستجابة أثناء التحميل")
        set(dl, "—", "اضغط الزر للقياس", 1)
        set(ul, "—", "اضغط الزر للقياس", 1)
        set(load, "—", "تُقاس أثناء اختبار السرعة", 1)
        set(dns, "—", "جارٍ القياس…", 1)

        testBtn = button(testLabel, 0xFF2563EB.toInt()) { runSpeedTest(it) }
        root.addView(testBtn, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        val share = button("مشاركة التقرير", 0xFF374151.toInt()) { shareReport() }
        root.addView(share, LinearLayout.LayoutParams(-1, -2))

        setContentView(ScrollView(this).apply {
            setBackgroundColor(0xFF0F131A.toInt()); addView(root)
        })
    }

    private fun button(label: String, color: Int, click: (TextView) -> Unit): TextView =
        TextView(this).apply {
            text = label; textSize = 17f; typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            setPadding(0, dp(14), 0, dp(14))
            background = GradientDrawable().apply { setColor(color); cornerRadius = dp(14).toFloat() }
            setOnClickListener { click(this) }
        }

    private fun cardBg() = GradientDrawable().apply { setColor(0xFF1E2430.toInt()); cornerRadius = dp(14).toFloat() }

    private fun graphCard(parent: LinearLayout) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = cardBg()
        }
        card.addView(TextView(this).apply {
            text = "زمن الاستجابة خلال آخر دقيقة"; textSize = 13f; setTextColor(0xFF9AA4B5.toInt())
        })
        graph = Graph(this, maxN)
        card.addView(graph, LinearLayout.LayoutParams(-1, dp(110)).apply { topMargin = dp(8) })
        val lg = LinearLayout(this).apply { gravity = Gravity.CENTER }
        lg.addView(TextView(this).apply { text = "● الراوتر"; textSize = 13f; setTextColor(0xFF4CAF50.toInt()) })
        lg.addView(TextView(this).apply {
            text = "● الإنترنت"; textSize = 13f; setTextColor(0xFF4DA3FF.toInt()); setPadding(dp(16), 0, 0, 0)
        })
        lg.addView(TextView(this).apply {
            text = "| خط أحمر = فقدان"; textSize = 13f; setTextColor(0xFFF44336.toInt()); setPadding(dp(16), 0, 0, 0)
        })
        card.addView(lg)
        parent.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
    }

    private fun row(parent: LinearLayout, title: String): Row {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = cardBg()
        }
        card.addView(TextView(this).apply { text = title; textSize = 13f; setTextColor(0xFF9AA4B5.toInt()) })
        val line = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val v = TextView(this).apply { textSize = 24f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE) }
        val n = TextView(this).apply { textSize = 16f; setPadding(dp(12), 0, 0, 0) }
        line.addView(v); line.addView(n); card.addView(line)
        parent.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        return Row(title, v, n).also { rows.add(it) }
    }

    private fun set(r: Row, value: String, note: String, lv: Int) {
        r.value.text = value
        r.note.text = note
        r.note.setTextColor(colors[lv])
    }

    // ───────────── دورة الحياة والقياس المستمر ─────────────

    override fun onStart() {
        super.onStart()
        alive = true
        val my = ++gen
        loop(my, 700) { val ms = pingGateway(); ui.post { onSample(true, ms) } }
        loop(my, 700) { val ms = pingNet(); ui.post { onSample(false, ms) } }
        loop(my, 6000) { val ms = dnsMs(); ui.post { onDns(ms) } }
    }

    override fun onStop() {
        super.onStop()
        alive = false
        for (t in threads) t.interrupt()
        threads.clear()
    }

    private fun loop(my: Int, period: Long, body: () -> Unit) {
        val t = Thread {
            while (alive && my == gen) {
                val t0 = SystemClock.elapsedRealtime()
                try { body() } catch (e: Exception) { }
                val rest = period - (SystemClock.elapsedRealtime() - t0)
                if (rest > 0) try { Thread.sleep(rest) } catch (e: InterruptedException) { }
            }
        }
        threads.add(t)
        t.start()
    }

    // يرجع الزمن بالميلي ثانية، أو -1 عند الفشل. "رفض الاتصال" يُعد استجابة صحيحة (الجهاز ردّ).
    private fun tcpPing(host: String, port: Int, timeout: Int): Int {
        val t0 = SystemClock.elapsedRealtime()
        return try {
            Socket().use { it.connect(InetSocketAddress(host, port), timeout) }
            (SystemClock.elapsedRealtime() - t0).toInt()
        } catch (e: ConnectException) {
            if (e.message?.contains("refused", true) == true) (SystemClock.elapsedRealtime() - t0).toInt() else -1
        } catch (e: Exception) {
            -1
        }
    }

    private fun findGateway(): String? {
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val n = cm.activeNetwork ?: return null
        val caps = cm.getNetworkCapabilities(n) ?: return null
        if (!caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) return null
        val lp = cm.getLinkProperties(n) ?: return null
        for (r in lp.routes) {
            val g = r.gateway
            if (r.isDefaultRoute && g is Inet4Address) return g.hostAddress
        }
        return null
    }

    // -2 = لا يوجد راوتر (غير متصل بوايفاي)
    private fun pingGateway(): Int {
        val g = findGateway() ?: return -2
        var r = tcpPing(g, gwPort, 800)
        if (r >= 0) return r
        for (p in intArrayOf(80, 53, 443, 8080)) {
            if (p == gwPort) continue
            r = tcpPing(g, p, 300)
            if (r >= 0) { gwPort = p; return r }
        }
        return -1
    }

    private fun pingNet(): Int {
        var r = tcpPing("1.1.1.1", 443, 1500)
        if (r < 0) r = tcpPing("8.8.8.8", 443, 1000)
        return r
    }

    // زمن البحث عن اسم جديد غير مخزّن (يقيس سرعة خادم DNS الفعلي)
    private fun dnsMs(): Int {
        val t0 = SystemClock.elapsedRealtime()
        try { InetAddress.getByName("x" + System.nanoTime() + ".google.com") } catch (e: Exception) { }
        return (SystemClock.elapsedRealtime() - t0).toInt()
    }

    private fun onDns(ms: Int) {
        if (testing) return
        if ((netG.lastOrNull() ?: -1) < 0) return // لا إنترنت أصلًا — لا معنى للقياس
        dnsS.addLast(ms)
        if (dnsS.size > 3) dnsS.removeFirst()
        refresh()
    }

    private fun onSample(isGw: Boolean, ms: Int) {
        if (ms == -2) { // غير متصل بوايفاي
            gwG.clear(); gwS.clear()
            refresh()
            return
        }
        val g = if (isGw) gwG else netG
        g.addLast(ms)
        if (g.size > maxN) g.removeFirst()
        if (testing) {
            if (!isGw) loadSamples.add(ms)
        } else {
            val s = if (isGw) gwS else netS
            s.addLast(ms)
            if (s.size > 20) s.removeFirst()
        }
        graph.setData(gwG.toList(), netG.toList())
        refresh()
    }

    // ───────────── اختبار السرعة ─────────────

    private fun mbps(bytes: Long, ms: Long) = bytes * 8.0 / 1_000_000 / (ms / 1000.0)
    private fun fmt(m: Double) = String.format(Locale.US, "%.1f Mbps", m)

    private fun isOnWifi(): Boolean {
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val n = cm.activeNetwork ?: return false
        return cm.getNetworkCapabilities(n)?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
    }

    private fun runSpeedTest(btn: TextView) {
        if (testing) return
        if (!isOnWifi()) {
            set(dl, "—", "الاختبار يعمل على الوايفاي فقط حفاظًا على باقة البيانات", 0)
            return
        }
        testing = true
        loadSamples.clear()
        idleAvg = if (netS.isEmpty()) -1 else stat(netS).avg
        btn.text = "جارٍ القياس…"; btn.alpha = 0.6f
        set(dl, "…", "جارٍ قياس التحميل", 1)
        set(ul, "—", "بانتظار انتهاء التحميل", 1)
        set(load, "…", "جارٍ القياس", 1)
        Thread {
            try {
                val d = measureDown()
                ui.post { showDown(d) }
                SystemClock.sleep(400)
                ui.post { set(ul, "…", "جارٍ قياس الرفع", 1) }
                val u = measureUp()
                ui.post { showUp(u) }
            } catch (e: Exception) {
            } finally {
                ui.post {
                    showLoad()
                    testing = false
                    btn.text = testLabel; btn.alpha = 1f
                }
            }
        }.start()
    }

    // 4 اتصالات متوازية، مع تجاهل أول ثانية ونصف (فترة الإحماء) للحصول على رقم أدق
    private fun measureDown(): Double {
        val total = AtomicLong(0)
        val stop = AtomicBoolean(false)
        repeat(4) {
            Thread {
                var c: HttpURLConnection? = null
                try {
                    c = URL("https://speed.cloudflare.com/__down?bytes=100000000").openConnection() as HttpURLConnection
                    c.connectTimeout = 4000; c.readTimeout = 4000
                    c.inputStream.use { s ->
                        val buf = ByteArray(65536)
                        while (!stop.get()) {
                            val n = s.read(buf)
                            if (n < 0) break
                            total.addAndGet(n.toLong())
                        }
                    }
                } catch (e: Exception) {
                } finally { c?.disconnect() }
            }.start()
        }
        return watch(total, stop, dl, 8000)
    }

    private fun measureUp(): Double {
        val sent = AtomicLong(0)
        val stop = AtomicBoolean(false)
        repeat(3) {
            Thread {
                val body = ByteArray(65536)
                while (!stop.get()) {
                    var c: HttpURLConnection? = null
                    try {
                        val size = 10_000_000
                        c = URL("https://speed.cloudflare.com/__up").openConnection() as HttpURLConnection
                        c.requestMethod = "POST"; c.doOutput = true
                        c.connectTimeout = 4000; c.readTimeout = 8000
                        c.setFixedLengthStreamingMode(size)
                        c.outputStream.use { o ->
                            var left = size
                            while (!stop.get() && left > 0) {
                                val n = minOf(body.size, left)
                                o.write(body, 0, n)
                                left -= n
                                sent.addAndGet(n.toLong())
                            }
                        }
                        if (!stop.get()) c.responseCode
                    } catch (e: Exception) {
                        if (sent.get() == 0L) SystemClock.sleep(300)
                    } finally { c?.disconnect() }
                }
            }.start()
        }
        return watch(sent, stop, ul, 6500)
    }

    // يراقب العدّاد، يعرض التقدم، ويرجع السرعة المستقرة (أو -1 عند الفشل)
    private fun watch(counter: AtomicLong, stop: AtomicBoolean, target: Row, limitMs: Long): Double {
        val t0 = SystemClock.elapsedRealtime()
        var warmBytes = -1L
        var warmT = 0L
        var lastUi = 0L
        while (true) {
            SystemClock.sleep(150)
            val now = SystemClock.elapsedRealtime()
            val el = now - t0
            val tot = counter.get()
            if (warmBytes < 0 && el >= 1500) { warmBytes = tot; warmT = now }
            if (warmBytes >= 0 && now - lastUi > 400 && now > warmT) {
                lastUi = now
                val m = mbps(tot - warmBytes, now - warmT)
                ui.post { set(target, fmt(m), "جارٍ القياس", 1) }
            }
            if (el >= limitMs || tot > 300_000_000L) break
            if (el > 5000 && tot == 0L) break
        }
        stop.set(true)
        val end = SystemClock.elapsedRealtime()
        val got = counter.get() - warmBytes
        if (warmBytes < 0 || got < 50_000 || end <= warmT) return -1.0
        return mbps(got, end - warmT)
    }

    private fun showDown(m: Double) {
        if (m < 0) { set(dl, "—", "فشل القياس — تحقق من الإنترنت", 0); return }
        val lv = when { m >= 50 -> 3; m >= 25 -> 2; m >= 5 -> 1; else -> 0 }
        set(dl, fmt(m), arrayOf("بطيئة", "للتصفح فقط", "جيدة للبث HD", "ممتازة للبث 4K")[lv], lv)
    }

    private fun showUp(m: Double) {
        if (m < 0) { set(ul, "—", "فشل قياس الرفع", 0); return }
        val lv = when { m >= 20 -> 3; m >= 5 -> 2; m >= 1.5 -> 1; else -> 0 }
        set(ul, fmt(m), arrayOf("ضعيفة", "بطيئة لرفع الملفات", "جيدة للمكالمات المرئية", "ممتازة")[lv], lv)
    }

    // الاستجابة تحت الضغط: إن ارتفعت كثيرًا فالراوتر يختنق عند الاستهلاك (Bufferbloat)
    private fun showLoad() {
        val ok = loadSamples.filter { it >= 0 }
        if (ok.isEmpty()) { set(load, "—", "لم تُسجَّل قياسات", 1); return }
        val avg = ok.average().toInt()
        val lv = when { avg < 60 -> 3; avg < 120 -> 2; avg < 250 -> 1; else -> 0 }
        val extra = if (idleAvg >= 0 && avg > idleAvg) " (+${avg - idleAvg})" else ""
        set(load, "$avg ms$extra",
            arrayOf("يتأثر بشدة — المكالمات والألعاب تتقطع أثناء التحميل", "يتأثر بوضوح عند الضغط", "مقبول", "ممتاز — لا يتأثر بالتحميل")[lv], lv)
    }

    // ───────────── التحليل والعرض ─────────────

    private fun stat(s: Collection<Int>): St {
        val ok = s.filter { it >= 0 }
        val loss = if (s.isEmpty()) 0 else (s.size - ok.size) * 100 / s.size
        val avg = if (ok.isEmpty()) -1 else ok.average().toInt()
        val jit = if (ok.size < 2) 0 else ok.zipWithNext { a, c -> abs(a - c) }.average().toInt()
        return St(avg, loss, jit)
    }

    // يحدد أين المشكلة: الوايفاي، الراوتر/الإنترنت، أم DNS
    private fun diagnose(wifi: Boolean, sigLevel: Int, gw: St?, net: St?, dnsAvg: Int): Pair<String, Int> {
        if (!wifi) return "أنت غير متصل بوايفاي — القياس هنا للإنترنت العام فقط" to 0
        if (net == null) return "جارٍ التحليل…" to 1
        val gwBad = gw != null && (gw.avg < 0 || gw.loss >= 15 || gw.avg > 80)
        val netDown = net.avg < 0 || net.loss >= 30
        val netBad = net.loss >= 10 || net.avg >= 120 || net.jit >= 60
        return when {
            gwBad -> "المشكلة في الوايفاي نفسه: الاتصال بين جهازك والراوتر ضعيف أو مزدحم. اقترب من الراوتر أو استخدم نطاق 5 GHz." to 0
            netDown -> "الوايفاي سليم لكن الإنترنت منقطع أو متقطع — المشكلة من الراوتر أو شركة الإنترنت. جرّب إعادة تشغيل الراوتر." to 0
            netBad -> "الوايفاي سليم لكن الإنترنت بطيء أو غير مستقر — غالبًا من الخدمة أو بسبب استهلاك أجهزة أخرى للشبكة." to 1
            sigLevel == 0 -> "القياسات جيدة الآن لكن الإشارة ضعيفة — قد يسوء الاتصال إن ابتعدت أكثر عن الراوتر." to 1
            dnsAvg >= 300 -> "الإنترنت سريع لكن DNS بطيء. جرّب من إعدادات الهاتف ← DNS الخاص ← اكتب: dns.google" to 1
            else -> "كل شيء سليم ✓ الاتصال مناسب للبث والمكالمات والألعاب" to 3
        }
    }

    @Suppress("DEPRECATION")
    private fun refresh() {
        val levels = ArrayList<Int>()

        // الوايفاي
        val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
        val info = wm.connectionInfo
        val connected = wm.isWifiEnabled && info != null && info.rssi > -127 && info.rssi < 0
        var sigLevel = 0
        if (connected) {
            val r = info.rssi
            val ls = when { r >= -50 -> 3; r >= -60 -> 2; r >= -70 -> 1; else -> 0 }
            set(signal, "$r dBm", arrayOf("ضعيفة — اقترب من الراوتر", "متوسطة", "جيدة", "ممتازة")[ls], ls)
            levels.add(ls)
            sigLevel = ls

            val s = info.linkSpeed
            val ss = when { s >= 300 -> 3; s >= 100 -> 2; s >= 50 -> 1; else -> 0 }
            set(speed, "$s Mbps", arrayOf("بطيئة", "متوسطة", "جيدة", "سريعة")[ss], ss)

            val f = info.frequency
            val (bn, bs) = when {
                f < 3000 -> "2.4 GHz" to "مدى أبعد، أبطأ"
                f < 5900 -> "5 GHz" to "أسرع، مدى أقصر"
                else -> "6 GHz" to "الأسرع، مدى قصير"
            }
            val std = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                when (info.wifiStandard) { 4 -> "Wi-Fi 4"; 5 -> "Wi-Fi 5"; 6 -> "Wi-Fi 6"; 8 -> "Wi-Fi 7"; else -> "" }
            } else ""
            set(band, bn, if (std.isEmpty()) bs else "$bs • $std", if (f < 3000) 1 else 3)
        } else {
            set(signal, "—", "غير متصل بوايفاي", 0)
            set(speed, "—", "", 0)
            set(band, "—", "", 0)
            levels.add(0)
        }

        // الراوتر
        val gw = if (gwS.isEmpty()) null else stat(gwS)
        if (gw == null) {
            set(router, "—", if (connected) "جارٍ القياس…" else "غير متصل بوايفاي", if (connected) 1 else 0)
        } else {
            val la = when { gw.avg < 0 -> 0; gw.avg < 10 -> 3; gw.avg < 30 -> 2; gw.avg < 80 -> 1; else -> 0 }
            val ll = when { gw.loss >= 15 -> 0; gw.loss > 0 -> 1; else -> 3 }
            val lv = minOf(la, ll)
            val base = if (gw.avg < 0) "الراوتر لا يستجيب"
            else arrayOf("ضعيف — الوايفاي مزدحم أو بعيد", "متوسط", "جيد", "ممتاز")[la]
            set(router, if (gw.avg < 0) "—" else "${gw.avg} ms",
                if (gw.loss > 0 && gw.avg >= 0) "$base • فقدان ${gw.loss}%" else base, lv)
            levels.add(lv)
        }

        // الإنترنت: Ping / Jitter / فقدان
        val net = if (netS.isEmpty()) null else stat(netS)
        if (net != null) {
            val ls = when { net.loss == 0 -> 3; net.loss <= 10 -> 1; else -> 0 }
            set(loss, "${net.loss}%", arrayOf("فقدان كثير", "فقدان بسيط", "", "لا يوجد فقدان")[ls], ls)
            levels.add(ls)

            if (net.avg < 0) {
                set(ping, "—", "لا يوجد إنترنت", 0)
                set(jitter, "—", "", 0)
                levels.add(0)
            } else {
                val ps = when { net.avg < 30 -> 3; net.avg < 60 -> 2; net.avg < 120 -> 1; else -> 0 }
                set(ping, "${net.avg} ms", arrayOf("بطيء", "متوسط", "جيد للتصفح", "ممتاز للألعاب")[ps], ps)
                levels.add(ps)

                val js = when { net.jit < 10 -> 3; net.jit < 30 -> 2; net.jit < 60 -> 1; else -> 0 }
                set(jitter, "${net.jit} ms", arrayOf("متذبذب جدًا — المكالمات تتقطع", "متذبذب قليلًا", "مقبول", "مستقر")[js], js)
                levels.add(js)
            }
        }

        // DNS
        var dnsAvg = -1
        if (dnsS.isNotEmpty()) {
            dnsAvg = dnsS.average().toInt()
            val ds = when { dnsAvg < 120 -> 3; dnsAvg < 300 -> 2; dnsAvg < 700 -> 1; else -> 0 }
            set(dns, "$dnsAvg ms", arrayOf("بطيء جدًا — المواقع ستتأخر في الفتح", "بطيء", "مقبول", "سريع")[ds], ds)
            levels.add(ds)
        }

        if (net != null) {
            val v = levels.min()
            verdict.text = arrayOf("اتصالك ضعيف", "اتصالك متوسط", "اتصالك جيد", "اتصالك ممتاز")[v]
            verdict.setTextColor(colors[v])
        }
        val d = diagnose(connected, sigLevel, gw, net, dnsAvg)
        diag.text = d.first
        diag.setTextColor(if (d.second == 3) colors[3] else colors[d.second])
    }

    // ───────────── مشاركة التقرير ─────────────

    private fun shareReport() {
        val sb = StringBuilder("تقرير جودة الوايفاي\n")
        sb.append(verdict.text).append("\n").append(diag.text).append("\n\n")
        for (r in rows) {
            sb.append("• ").append(r.title).append(": ").append(r.value.text)
            if (r.note.text.isNotEmpty()) sb.append(" — ").append(r.note.text)
            sb.append("\n")
        }
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, sb.toString())
        }
        startActivity(Intent.createChooser(i, "مشاركة التقرير"))
    }
}
