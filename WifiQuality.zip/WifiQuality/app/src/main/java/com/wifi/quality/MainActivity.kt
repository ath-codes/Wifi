package com.wifi.quality

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.location.LocationManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.ConnectivityManager
import android.net.Uri
import android.net.wifi.ScanResult
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.InetAddress
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.abs

class MainActivity : Activity() {

    private class Row(val title: String, val value: TextView, val note: TextView, val card: View)
    private class St(val avg: Int, val loss: Int, val jit: Int)
    private class Dns(val label: String, val ip: String, val host: String?)
    private class DnsRes(val label: String, val host: String?, val ms: Int)
    private class Sec(val box: LinearLayout, val btn: TextView)

    private val ui = Handler(Looper.getMainLooper())
    private val maxN = 80
    private val netG = ArrayDeque<Int>()      // للرسم البياني (-1 = فشل)
    private val gwG = ArrayDeque<Int>()
    private val netS = ArrayDeque<Int>()      // للإحصاءات (آخر 20) — تتجمد أثناء اختبار السرعة
    private val gwS = ArrayDeque<Int>()
    private val dnsS = ArrayDeque<Int>()
    private val loadSamples = ArrayList<Int>()
    private var idleAvg = -1
    private var lastDl = -1.0
    private var lastUl = -1.0

    @Volatile private var alive = false
    @Volatile private var gen = 0
    @Volatile private var gwPort = 80
    @Volatile private var testing = false
    @Volatile private var paused = false
    private val threads = ArrayList<Thread>()
    private val rows = ArrayList<Row>()
    private val details = ArrayList<Row>()
    private var detailsOpen = false

    private val tabs = ArrayList<TextView>()
    private val scrolls = ArrayList<ScrollView>()
    private lateinit var pgLive: LinearLayout
    private lateinit var pgTools: LinearLayout
    private lateinit var pgHist: LinearLayout

    private lateinit var verdict: TextView
    private lateinit var diag: TextView
    private lateinit var roomChip: TextView
    private lateinit var pauseBtn: TextView
    private lateinit var graph: Graph
    private lateinit var gauge: Gauge
    private lateinit var testBtn: TextView
    private lateinit var chBox: LinearLayout
    private lateinit var dnsBox: LinearLayout
    private lateinit var walkBox: LinearLayout
    private lateinit var walkBtn: TextView
    private var dnsBusy = false

    private lateinit var signal: Row
    private lateinit var router: Row
    private lateinit var ping: Row
    private lateinit var loss: Row
    private lateinit var jitter: Row
    private lateinit var dns: Row
    private lateinit var speed: Row
    private lateinit var band: Row
    private lateinit var dl: Row
    private lateinit var ul: Row
    private lateinit var load: Row

    private val colors = intArrayOf(0xFFF44336.toInt(), 0xFFFFC107.toInt(), 0xFF8BC34A.toInt(), 0xFF4CAF50.toInt())
    private val gray = 0xFF9AA4B5.toInt()
    private val blue = 0xFF4DA3FF.toInt()
    private val testLabel = "اختبر السرعة (تحميل + رفع)"
    private val df = SimpleDateFormat("EEE d/M HH:mm", Locale.getDefault())

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ───────────── بناء الواجهة ─────────────

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val main = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(0xFF0F131A.toInt())
            setPadding(0, dp(28), 0, 0)
        }
        val tabBar = LinearLayout(this).apply { setPadding(dp(12), dp(8), dp(12), dp(8)) }
        val names = arrayOf("مباشر", "أدوات", "السجل")
        for (i in names.indices) {
            val t = TextView(this).apply {
                text = names[i]; textSize = 16f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
                setTextColor(Color.WHITE); setPadding(0, dp(10), 0, dp(10))
                setOnClickListener { showTab(i) }
            }
            tabs.add(t)
            tabBar.addView(t, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(4); rightMargin = dp(4) })
        }

        pgLive = newPage(); pgTools = newPage(); pgHist = newPage()
        val frame = FrameLayout(this)
        for (p in arrayOf(pgLive, pgTools, pgHist)) {
            val sc = ScrollView(this)
            sc.addView(p)
            scrolls.add(sc)
            frame.addView(sc, FrameLayout.LayoutParams(-1, -1))
        }
        main.addView(tabBar, LinearLayout.LayoutParams(-1, -2))
        main.addView(frame, LinearLayout.LayoutParams(-1, 0, 1f))

        buildLive()
        buildTools()
        setContentView(main)
        showTab(0)

        if (Store.monitorOn(this)) {
            try { startForegroundService(Intent(this, MonitorService::class.java)) } catch (e: Exception) { }
        }
    }

    private fun newPage() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        layoutDirection = View.LAYOUT_DIRECTION_RTL
        setPadding(dp(16), dp(8), dp(16), dp(24))
    }

    private fun showTab(i: Int) {
        for (j in scrolls.indices) scrolls[j].visibility = if (j == i) View.VISIBLE else View.GONE
        for (j in tabs.indices) {
            tabs[j].background = GradientDrawable().apply {
                setColor(if (j == i) 0xFF2563EB.toInt() else 0xFF1E2430.toInt()); cornerRadius = dp(12).toFloat()
            }
        }
        if (i == 2) renderHistory()
    }

    private fun buildLive() {
        verdict = TextView(this).apply {
            textSize = 28f; typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            setPadding(0, dp(8), 0, dp(6)); text = "…"
        }
        pgLive.addView(verdict)
        diag = TextView(this).apply {
            textSize = 15f; gravity = Gravity.CENTER; setTextColor(gray)
            setPadding(dp(8), 0, dp(8), dp(10)); text = "جارٍ التحليل…"
        }
        pgLive.addView(diag)

        roomChip = TextView(this).apply {
            textSize = 14f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(dp(16), dp(8), dp(16), dp(8))
            background = GradientDrawable().apply { setColor(0xFF2A3342.toInt()); cornerRadius = dp(20).toFloat() }
            setOnClickListener { editRoom() }
        }
        pgLive.addView(roomChip, LinearLayout.LayoutParams(-2, -2).apply { gravity = Gravity.CENTER_HORIZONTAL; bottomMargin = dp(14) })
        updateRoomChip()

        graphCard(pgLive)

        signal = row(pgLive, "قوة الإشارة")
        router = row(pgLive, "الاتصال بالراوتر (داخل البيت)")
        ping = row(pgLive, "الاتصال بالإنترنت (Ping)")
        loss = row(pgLive, "فقدان الحزم")

        val more = TextView(this).apply {
            text = "عرض كل التفاصيل ▾"; textSize = 15f; setTextColor(blue); gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(14))
        }
        more.setOnClickListener {
            detailsOpen = !detailsOpen
            for (r in details) r.card.visibility = if (detailsOpen) View.VISIBLE else View.GONE
            more.text = if (detailsOpen) "إخفاء التفاصيل ▴" else "عرض كل التفاصيل ▾"
        }
        pgLive.addView(more, LinearLayout.LayoutParams(-1, -2))

        jitter = row(pgLive, "الثبات (Jitter)")
        dns = row(pgLive, "سرعة DNS (فتح المواقع)")
        speed = row(pgLive, "سرعة الربط")
        band = row(pgLive, "النطاق")
        details.add(jitter); details.add(dns); details.add(speed); details.add(band)
        for (r in details) r.card.visibility = View.GONE
        set(dns, "—", "جارٍ القياس…", 1)

        pauseBtn = button("إيقاف القياس مؤقتًا", 0xFF374151.toInt()) { togglePause() }
        pgLive.addView(pauseBtn, LinearLayout.LayoutParams(-1, -2))
    }

    private fun buildTools() {
        // اختبار السرعة مع العداد الدائري
        val gc = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(14))
            background = cardBg()
        }
        gauge = Gauge(this)
        gauge.setValue(0.0, "اضغط للقياس")
        gc.addView(gauge, LinearLayout.LayoutParams(-1, dp(190)))
        testBtn = button(testLabel, 0xFF2563EB.toInt()) { runSpeedTest(it) }
        gc.addView(testBtn, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        pgTools.addView(gc, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })

        dl = row(pgTools, "سرعة التحميل")
        ul = row(pgTools, "سرعة الرفع")
        load = row(pgTools, "الاستجابة أثناء التحميل")
        set(dl, "—", "اضغط الزر للقياس", 1)
        set(ul, "—", "اضغط الزر للقياس", 1)
        set(load, "—", "تُقاس أثناء اختبار السرعة", 1)

        val walk = section(pgTools, "وضع التجوال — ابحث عن أفضل مكان", "ابدأ التجوال") { toggleWalk() }
        walkBox = walk.box; walkBtn = walk.btn
        line(walkBox, "امشِ في البيت ببطء: كلما أسرعت النغمات قويت الإشارة. اجلس أو ضع الراوتر في أسرع مكان.", gray)

        val ch = section(pgTools, "فحص قنوات الوايفاي (2.4 GHz)", "افحص القنوات المجاورة") { scanChannels() }
        chBox = ch.box
        line(chBox, "يحدد أقل القنوات ازدحامًا ويقترح أفضلها", gray)

        val dn = section(pgTools, "أسرع DNS", "اختبر خوادم DNS") { benchDns() }
        dnsBox = dn.box
        line(dnsBox, "يقارن خوادم DNS المشهورة ويقترح الأسرع", gray)

        pgTools.addView(button("مشاركة التقرير", 0xFF374151.toInt()) { shareReport() }, LinearLayout.LayoutParams(-1, -2))
    }

    private fun button(label: String, color: Int, click: (TextView) -> Unit): TextView =
        TextView(this).apply {
            text = label; textSize = 17f; typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            setPadding(0, dp(14), 0, dp(14))
            background = GradientDrawable().apply { setColor(color); cornerRadius = dp(14).toFloat() }
            setOnClickListener { click(this) }
        }

    private fun cardBg() = GradientDrawable().apply { setColor(0xFF1E2430.toInt()); cornerRadius = dp(14).toFloat() }

    private fun graphCard(parent: LinearLayout) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = cardBg()
        }
        card.addView(TextView(this).apply {
            text = "زمن الاستجابة خلال آخر دقيقة"; textSize = 13f; setTextColor(gray)
        })
        graph = Graph(this, maxN)
        card.addView(graph, LinearLayout.LayoutParams(-1, dp(110)).apply { topMargin = dp(8) })
        val lg = LinearLayout(this).apply { gravity = Gravity.CENTER }
        lg.addView(TextView(this).apply { text = "● الراوتر"; textSize = 13f; setTextColor(0xFF4CAF50.toInt()) })
        lg.addView(TextView(this).apply {
            text = "● الإنترنت"; textSize = 13f; setTextColor(blue); setPadding(dp(16), 0, 0, 0)
        })
        lg.addView(TextView(this).apply {
            text = "| خط أحمر = فقدان"; textSize = 13f; setTextColor(0xFFF44336.toInt()); setPadding(dp(16), 0, 0, 0)
        })
        card.addView(lg)
        parent.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
    }

    private fun row(parent: LinearLayout, title: String): Row {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = cardBg()
        }
        card.addView(TextView(this).apply { text = title; textSize = 13f; setTextColor(gray) })
        val lineL = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val v = TextView(this).apply { textSize = 24f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE) }
        val n = TextView(this).apply { textSize = 16f; setPadding(dp(12), 0, 0, 0) }
        lineL.addView(v); lineL.addView(n); card.addView(lineL)
        parent.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        return Row(title, v, n, card).also { rows.add(it) }
    }

    private fun set(r: Row, value: String, note: String, lv: Int) {
        r.value.text = value
        r.note.text = note
        r.note.setTextColor(colors[lv])
    }

    private fun card(parent: LinearLayout, title: String): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = cardBg()
        }
        c.addView(TextView(this).apply { text = title; textSize = 13f; setTextColor(gray) })
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        c.addView(box, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        parent.addView(c, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        return box
    }

    private fun section(parent: LinearLayout, title: String, label: String, click: () -> Unit): Sec {
        val box = card(parent, title)
        val btn = button(label, 0xFF2563EB.toInt()) { click() }
        (box.parent as LinearLayout).addView(btn, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        return Sec(box, btn)
    }

    private fun line(box: LinearLayout, msg: String, color: Int = Color.WHITE, onClick: (() -> Unit)? = null) {
        val t = TextView(this)
        t.text = msg
        t.textSize = 15f
        t.setTextColor(color)
        t.setPadding(0, dp(6), 0, dp(6))
        if (onClick != null) {
            t.setPadding(dp(12), dp(10), dp(12), dp(10))
            t.background = GradientDrawable().apply { setColor(0xFF2A3342.toInt()); cornerRadius = dp(10).toFloat() }
            t.setOnClickListener { onClick() }
            box.addView(t, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        } else {
            box.addView(t)
        }
    }

    private fun askText(title: String, hint: String, init: String, numeric: Boolean, ok: (String) -> Unit) {
        val et = EditText(this)
        et.setText(init)
        et.hint = hint
        if (numeric) et.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        val wrap = LinearLayout(this).apply { setPadding(dp(20), dp(8), dp(20), 0) }
        wrap.addView(et, LinearLayout.LayoutParams(-1, -2))
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(wrap)
            .setPositiveButton("حفظ") { _, _ -> ok(et.text.toString().trim()) }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun updateRoomChip() {
        val r = Store.room(this)
        roomChip.text = "المكان: " + (if (r.isEmpty()) "اضغط لتسميته" else r) + " ✎"
    }

    private fun editRoom() {
        askText("اسم المكان الحالي", "مثال: الصالة", Store.room(this), false) {
            Store.setRoom(this, it)
            updateRoomChip()
        }
    }

    private fun togglePause() {
        paused = !paused
        if (paused) {
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            pauseBtn.text = "استئناف القياس"
            verdict.text = "القياس متوقف مؤقتًا"
            verdict.setTextColor(gray)
            diag.text = "اضغط «استئناف القياس» للمتابعة (توقيفه يوفر البطارية)"
            diag.setTextColor(gray)
        } else {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            pauseBtn.text = "إيقاف القياس مؤقتًا"
        }
    }

    // ───────────── دورة الحياة والقياس المستمر ─────────────

    override fun onStart() {
        super.onStart()
        alive = true
        val my = ++gen
        loop(my, 700) { val ms = pingGateway(); ui.post { onSample(true, ms) } }
        loop(my, 700) { val ms = NetProbe.pingNet(); ui.post { onSample(false, ms) } }
        loop(my, 6000) { val ms = dnsMs(); ui.post { onDns(ms) } }
    }

    override fun onStop() {
        super.onStop()
        alive = false
        for (t in threads) t.interrupt()
        threads.clear()
        stopWalk()
    }

    private fun loop(my: Int, period: Long, body: () -> Unit) {
        val t = Thread {
            while (alive && my == gen) {
                val t0 = SystemClock.elapsedRealtime()
                if (!paused) {
                    try { body() } catch (e: Exception) { }
                }
                val rest = period - (SystemClock.elapsedRealtime() - t0)
                if (rest > 0) try { Thread.sleep(rest) } catch (e: InterruptedException) { }
            }
        }
        threads.add(t)
        t.start()
    }

    // -2 = لا يوجد راوتر (غير متصل بوايفاي)
    private fun pingGateway(): Int {
        val g = NetProbe.findGateway(this) ?: return -2
        var r = NetProbe.tcpPing(g, gwPort, 800)
        if (r >= 0) return r
        for (p in intArrayOf(80, 53, 443, 8080)) {
            if (p == gwPort) continue
            r = NetProbe.tcpPing(g, p, 300)
            if (r >= 0) { gwPort = p; return r }
        }
        return -1
    }

    // زمن البحث عن اسم جديد غير مخزّن (يقيس سرعة خادم DNS الفعلي)
    private fun dnsMs(): Int {
        val t0 = SystemClock.elapsedRealtime()
        try { InetAddress.getByName("x" + System.nanoTime() + ".google.com") } catch (e: Exception) { }
        return (SystemClock.elapsedRealtime() - t0).toInt()
    }

    private fun onDns(ms: Int) {
        if (testing) return
        if ((netG.lastOrNull() ?: -1) < 0) return
        dnsS.addLast(ms)
        if (dnsS.size > 3) dnsS.removeFirst()
        refresh()
    }

    private fun onSample(isGw: Boolean, ms: Int) {
        if (ms == -2) {
            gwG.clear(); gwS.clear()
            refresh()
            return
        }
        val g = if (isGw) gwG else netG
        g.addLast(ms)
        if (g.size > maxN) g.removeFirst()
        if (testing) {
            if (!isGw) loadSamples.add(ms)
        } else {
            val s = if (isGw) gwS else netS
            s.addLast(ms)
            if (s.size > 20) s.removeFirst()
        }
        graph.setData(gwG.toList(), netG.toList())
        refresh()
    }

    // ───────────── اختبار السرعة ─────────────

    private fun mbps(bytes: Long, ms: Long) = bytes * 8.0 / 1_000_000 / (ms / 1000.0)
    private fun fmt(m: Double) = String.format(Locale.US, "%.1f Mbps", m)
    private fun num(v: Double) = String.format(Locale.US, "%.0f", v)

    private fun runSpeedTest(btn: TextView) {
        if (testing) return
        if (!NetProbe.onWifi(this)) {
            set(dl, "—", "الاختبار يعمل على الوايفاي فقط حفاظًا على باقة البيانات", 0)
            return
        }
        testing = true
        lastDl = -1.0; lastUl = -1.0
        loadSamples.clear()
        idleAvg = if (netS.isEmpty()) -1 else stat(netS).avg
        btn.text = "جارٍ القياس…"; btn.alpha = 0.6f
        gauge.setValue(0.0, "تحميل")
        set(dl, "…", "جارٍ قياس التحميل", 1)
        set(ul, "—", "بانتظار انتهاء التحميل", 1)
        set(load, "…", "جارٍ القياس", 1)
        Thread {
            try {
                val d = measureDown()
                ui.post { showDown(d, false) }
                SystemClock.sleep(400)
                ui.post { set(ul, "…", "جارٍ قياس الرفع", 1); gauge.setValue(0.0, "رفع") }
                val u = measureUp()
                ui.post { showUp(u) }
            } catch (e: Exception) {
            } finally {
                ui.post {
                    showLoad()
                    if (lastDl > 0 || lastUl > 0) {
                        Store.addTest(this, TestEntry(System.currentTimeMillis(), Store.room(this), lastDl, lastUl, currentRssi() ?: 0, idleAvg))
                        if (lastDl > 0) showDown(lastDl, true)
                    }
                    testing = false
                    btn.text = testLabel; btn.alpha = 1f
                }
            }
        }.start()
    }

    private val lastErr = java.util.concurrent.atomic.AtomicReference("")
    private val downUrls = arrayOf(
        "https://speed.cloudflare.com/__down?bytes=25000000",
        "https://cachefly.cachefly.net/50mb.test",
        "https://proof.ovh.net/files/100Mb.dat"
    )

    // 4 اتصالات متوازية تعيد الطلب باستمرار حتى انتهاء الوقت، وتنتقل لمصدر بديل إن فشل الأول
    private fun measureDown(): Double {
        val total = AtomicLong(0)
        val stop = AtomicBoolean(false)
        lastErr.set("")
        repeat(4) {
            Thread {
                var u = 0
                while (!stop.get() && u < downUrls.size) {
                    var c: HttpURLConnection? = null
                    val before = total.get()
                    try {
                        c = URL(downUrls[u]).openConnection() as HttpURLConnection
                        c.connectTimeout = 5000; c.readTimeout = 5000
                        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) WifiQuality/1.4")
                        c.setRequestProperty("Accept-Encoding", "identity")
                        val code = c.responseCode
                        if (code != 200) {
                            lastErr.set("HTTP $code")
                            u++
                            continue
                        }
                        c.inputStream.use { s ->
                            val buf = ByteArray(65536)
                            while (!stop.get()) {
                                val n = s.read(buf)
                                if (n < 0) break
                                total.addAndGet(n.toLong())
                            }
                        }
                        if (total.get() == before) u++
                    } catch (e: Exception) {
                        lastErr.set(e.javaClass.simpleName)
                        if (total.get() == before) u++
                    } finally { c?.disconnect() }
                }
            }.start()
        }
        return watch(total, stop, dl, 8000)
    }

    private fun measureUp(): Double {
        val sent = AtomicLong(0)
        val stop = AtomicBoolean(false)
        lastErr.set("")
        repeat(3) {
            Thread {
                val body = ByteArray(65536)
                while (!stop.get()) {
                    var c: HttpURLConnection? = null
                    try {
                        val size = 10_000_000
                        c = URL("https://speed.cloudflare.com/__up").openConnection() as HttpURLConnection
                        c.requestMethod = "POST"; c.doOutput = true
                        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) WifiQuality/1.4")
                        c.connectTimeout = 4000; c.readTimeout = 8000
                        c.setFixedLengthStreamingMode(size)
                        c.outputStream.use { o ->
                            var left = size
                            while (!stop.get() && left > 0) {
                                val n = minOf(body.size, left)
                                o.write(body, 0, n)
                                left -= n
                                sent.addAndGet(n.toLong())
                            }
                        }
                        if (!stop.get()) {
                            val code = c.responseCode
                            if (code >= 400) { lastErr.set("HTTP $code"); SystemClock.sleep(300) }
                        }
                    } catch (e: Exception) {
                        lastErr.set(e.javaClass.simpleName)
                        if (sent.get() == 0L) SystemClock.sleep(300)
                    } finally { c?.disconnect() }
                }
            }.start()
        }
        return watch(sent, stop, ul, 6500)
    }

    // يراقب العدّاد، يعرض التقدم، ويرجع السرعة المستقرة (أو -1 عند الفشل)
    private fun watch(counter: AtomicLong, stop: AtomicBoolean, target: Row, limitMs: Long): Double {
        val isDown = target === dl
        val t0 = SystemClock.elapsedRealtime()
        var warmBytes = -1L
        var warmT = 0L
        var lastUi = 0L
        while (true) {
            SystemClock.sleep(150)
            val now = SystemClock.elapsedRealtime()
            val el = now - t0
            val tot = counter.get()
            if (warmBytes < 0 && el >= 1500) { warmBytes = tot; warmT = now }
            if (warmBytes >= 0 && now - lastUi > 400 && now > warmT) {
                lastUi = now
                val m = mbps(tot - warmBytes, now - warmT)
                ui.post {
                    set(target, fmt(m), "جارٍ القياس", 1)
                    gauge.setValue(m, if (isDown) "تحميل" else "رفع")
                }
            }
            if (el >= limitMs || tot > 300_000_000L) break
            if (el > 5000 && tot == 0L) break
        }
        stop.set(true)
        val end = SystemClock.elapsedRealtime()
        val got = counter.get() - warmBytes
        if (warmBytes < 0 || got < 50_000 || end <= warmT) return -1.0
        return mbps(got, end - warmT)
    }

    private fun failMsg(base: String): String {
        val e = lastErr.get()
        return if (e.isEmpty()) base else "$base ($e)"
    }

    private fun dlExtra(): String {
        val h = Store.tests(this).filter { it.dl > 0 }.takeLast(3)
        val sb = StringBuilder()
        if (h.size >= 2) sb.append(" • متوسط آخر ").append(h.size).append(": ").append(num(h.map { it.dl }.average()))
        val plan = Store.plan(this)
        if (plan > 0f && lastDl > 0) sb.append(" • ").append((lastDl / plan * 100).toInt()).append("% من باقتك")
        return sb.toString()
    }

    private fun showDown(m: Double, extra: Boolean) {
        if (m < 0) { set(dl, "—", failMsg("فشل القياس — تحقق من الإنترنت"), 0); return }
        lastDl = m
        gauge.setValue(m, "تحميل")
        val lv = when { m >= 50 -> 3; m >= 25 -> 2; m >= 5 -> 1; else -> 0 }
        val base = arrayOf("بطيئة", "للتصفح فقط", "جيدة للبث HD", "ممتازة للبث 4K")[lv]
        set(dl, fmt(m), base + (if (extra) dlExtra() else ""), lv)
    }

    private fun showUp(m: Double) {
        if (m < 0) { set(ul, "—", failMsg("فشل قياس الرفع"), 0); return }
        lastUl = m
        gauge.setValue(m, "رفع")
        val lv = when { m >= 20 -> 3; m >= 5 -> 2; m >= 1.5 -> 1; else -> 0 }
        set(ul, fmt(m), arrayOf("ضعيفة", "بطيئة لرفع الملفات", "جيدة للمكالمات المرئية", "ممتازة")[lv], lv)
    }

    // الاستجابة تحت الضغط: إن ارتفعت كثيرًا فالراوتر يختنق عند الاستهلاك (Bufferbloat)
    private fun showLoad() {
        val ok = loadSamples.filter { it >= 0 }
        if (ok.isEmpty()) { set(load, "—", "لم تُسجَّل قياسات", 1); return }
        val avg = ok.average().toInt()
        val lv = when { avg < 60 -> 3; avg < 120 -> 2; avg < 250 -> 1; else -> 0 }
        val extra = if (idleAvg >= 0 && avg > idleAvg) " (+${avg - idleAvg})" else ""
        set(load, "$avg ms$extra",
            arrayOf("يتأثر بشدة — المكالمات والألعاب تتقطع أثناء التحميل", "يتأثر بوضوح عند الضغط", "مقبول", "ممتاز — لا يتأثر بالتحميل")[lv], lv)
    }

    // ───────────── التحليل والعرض ─────────────

    private fun stat(s: Collection<Int>): St {
        val ok = s.filter { it >= 0 }
        val lossP = if (s.isEmpty()) 0 else (s.size - ok.size) * 100 / s.size
        val avg = if (ok.isEmpty()) -1 else ok.average().toInt()
        val jit = if (ok.size < 2) 0 else ok.zipWithNext { a, c -> abs(a - c) }.average().toInt()
        return St(avg, lossP, jit)
    }

    private fun diagnose(wifi: Boolean, sigLevel: Int, gw: St?, net: St?, dnsAvg: Int): Pair<String, Int> {
        if (!wifi) return "أنت غير متصل بوايفاي — القياس هنا للإنترنت العام فقط" to 0
        if (net == null) return "جارٍ التحليل…" to 1
        val gwBad = gw != null && (gw.avg < 0 || gw.loss >= 15 || gw.avg > 80)
        val netDown = net.avg < 0 || net.loss >= 30
        val netBad = net.loss >= 10 || net.avg >= 120 || net.jit >= 60
        return when {
            gwBad -> "المشكلة في الوايفاي نفسه: الاتصال بين جهازك والراوتر ضعيف أو مزدحم. اقترب من الراوتر أو افحص القنوات من تبويب «أدوات»." to 0
            netDown -> "الوايفاي سليم لكن الإنترنت منقطع أو متقطع — المشكلة من الراوتر أو شركة الإنترنت. جرّب إعادة تشغيل الراوتر." to 0
            netBad -> "الوايفاي سليم لكن الإنترنت بطيء أو غير مستقر — غالبًا من الخدمة أو بسبب استهلاك أجهزة أخرى للشبكة." to 1
            sigLevel == 0 -> "الأداء جيد الآن لكن الإشارة ضعيفة — قد يسوء الاتصال إن ابتعدت أكثر عن الراوتر." to 1
            dnsAvg >= 300 -> "الإنترنت سريع لكن DNS بطيء. جرّب اختبار DNS من تبويب «أدوات»." to 1
            else -> "كل شيء سليم ✓ الاتصال مناسب للبث والمكالمات والألعاب" to 3
        }
    }

    @Suppress("DEPRECATION")
    private fun currentRssi(): Int? {
        val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
        val i = wm.connectionInfo ?: return null
        return if (wm.isWifiEnabled && i.rssi > -127 && i.rssi < 0) i.rssi else null
    }

    @Suppress("DEPRECATION")
    private fun refresh() {
        if (paused) return
        val levels = ArrayList<Int>() // مقاييس الأداء الفعلي فقط — الإشارة تحذير وليست حكمًا

        val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
        val info = wm.connectionInfo
        val connected = wm.isWifiEnabled && info != null && info.rssi > -127 && info.rssi < 0
        var sigLevel = 0
        if (connected) {
            val r = info.rssi
            val ls = when { r >= -50 -> 3; r >= -60 -> 2; r >= -70 -> 1; else -> 0 }
            set(signal, "$r dBm", arrayOf("ضعيفة — اقترب من الراوتر", "متوسطة", "جيدة", "ممتازة")[ls], ls)
            sigLevel = ls

            val s = info.linkSpeed
            val ss = when { s >= 300 -> 3; s >= 100 -> 2; s >= 50 -> 1; else -> 0 }
            set(speed, "$s Mbps", arrayOf("بطيئة", "متوسطة", "جيدة", "سريعة")[ss], ss)

            val f = info.frequency
            val (bn, bs) = when {
                f < 3000 -> "2.4 GHz" to "مدى أبعد، أبطأ"
                f < 5900 -> "5 GHz" to "أسرع، مدى أقصر"
                else -> "6 GHz" to "الأسرع، مدى قصير"
            }
            val std = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                when (info.wifiStandard) { 4 -> "Wi-Fi 4"; 5 -> "Wi-Fi 5"; 6 -> "Wi-Fi 6"; 8 -> "Wi-Fi 7"; else -> "" }
            } else ""
            set(band, bn, if (std.isEmpty()) bs else "$bs • $std", if (f < 3000) 1 else 3)
        } else {
            set(signal, "—", "غير متصل بوايفاي", 0)
            set(speed, "—", "", 0)
            set(band, "—", "", 0)
        }

        val gw = if (gwS.isEmpty()) null else stat(gwS)
        if (gw == null) {
            set(router, "—", if (connected) "جارٍ القياس…" else "غير متصل بوايفاي", if (connected) 1 else 0)
        } else {
            val la = when { gw.avg < 0 -> 0; gw.avg < 10 -> 3; gw.avg < 30 -> 2; gw.avg < 80 -> 1; else -> 0 }
            val ll = when { gw.loss >= 15 -> 0; gw.loss > 0 -> 1; else -> 3 }
            val lv = minOf(la, ll)
            val base = if (gw.avg < 0) "الراوتر لا يستجيب"
            else arrayOf("ضعيف — الوايفاي مزدحم أو بعيد", "متوسط", "جيد", "ممتاز")[la]
            set(router, if (gw.avg < 0) "—" else "${gw.avg} ms",
                if (gw.loss > 0 && gw.avg >= 0) "$base • فقدان ${gw.loss}%" else base, lv)
            levels.add(lv)
        }

        val net = if (netS.isEmpty()) null else stat(netS)
        if (net != null) {
            val ls = when { net.loss == 0 -> 3; net.loss <= 10 -> 1; else -> 0 }
            set(loss, "${net.loss}%", arrayOf("فقدان كثير", "فقدان بسيط", "", "لا يوجد فقدان")[ls], ls)
            levels.add(ls)

            if (net.avg < 0) {
                set(ping, "—", "لا يوجد إنترنت", 0)
                set(jitter, "—", "", 0)
                levels.add(0)
            } else {
                val ps = when { net.avg < 30 -> 3; net.avg < 60 -> 2; net.avg < 120 -> 1; else -> 0 }
                set(ping, "${net.avg} ms", arrayOf("بطيء", "متوسط", "جيد للتصفح", "ممتاز للألعاب")[ps], ps)
                levels.add(ps)

                val js = when { net.jit < 10 -> 3; net.jit < 30 -> 2; net.jit < 60 -> 1; else -> 0 }
                set(jitter, "${net.jit} ms", arrayOf("متذبذب جدًا — المكالمات تتقطع", "متذبذب قليلًا", "مقبول", "مستقر")[js], js)
                levels.add(js)
            }
        }

        var dnsAvg = -1
        if (dnsS.isNotEmpty()) {
            dnsAvg = dnsS.average().toInt()
            val ds = when { dnsAvg < 120 -> 3; dnsAvg < 300 -> 2; dnsAvg < 700 -> 1; else -> 0 }
            set(dns, "$dnsAvg ms", arrayOf("بطيء جدًا — المواقع ستتأخر في الفتح", "بطيء", "مقبول", "سريع")[ds], ds)
        }

        if (net != null && levels.isNotEmpty()) {
            val v = levels.min()
            verdict.text = arrayOf("اتصالك ضعيف", "اتصالك متوسط", "اتصالك جيد", "اتصالك ممتاز")[v]
            verdict.setTextColor(colors[v])
        }
        val d = diagnose(connected, sigLevel, gw, net, dnsAvg)
        diag.text = d.first
        diag.setTextColor(colors[d.second])
    }

    // ───────────── وضع التجوال ─────────────

    private var walkOn = false
    private var walkMax = -200
    private var tone: ToneGenerator? = null
    private var walkVal: TextView? = null
    private var walkNote: TextView? = null

    private val walkTick: Runnable = object : Runnable {
        override fun run() {
            if (!walkOn) return
            val r = currentRssi()
            var delay = 1000L
            if (r == null) {
                walkVal?.text = "—"
                walkNote?.text = "غير متصل بوايفاي"
            } else {
                if (r > walkMax) walkMax = r
                val ls = when { r >= -50 -> 3; r >= -60 -> 2; r >= -70 -> 1; else -> 0 }
                walkVal?.text = "$r dBm"
                walkVal?.setTextColor(colors[ls])
                walkNote?.text = arrayOf("ضعيفة", "متوسطة", "جيدة", "ممتازة")[ls] + " • الأفضل حتى الآن: $walkMax dBm"
                try { tone?.startTone(ToneGenerator.TONE_PROP_BEEP, 70) } catch (e: Exception) { }
                val c = r.coerceIn(-90, -40)
                delay = (1600 - (c + 90) * 28).toLong()
            }
            ui.postDelayed(this, delay)
        }
    }

    private fun toggleWalk() {
        if (walkOn) { stopWalk(); return }
        walkOn = true
        walkMax = -200
        tone = try { ToneGenerator(AudioManager.STREAM_MUSIC, 70) } catch (e: Exception) { null }
        walkBtn.text = "إيقاف التجوال"
        walkBox.removeAllViews()
        val v = TextView(this).apply {
            textSize = 34f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setTextColor(Color.WHITE); text = "…"
        }
        val n = TextView(this).apply { textSize = 15f; gravity = Gravity.CENTER; setTextColor(gray) }
        walkVal = v; walkNote = n
        walkBox.addView(v)
        walkBox.addView(n)
        line(walkBox, "حفظ هذه القراءة للمكان الحالي ✎", Color.WHITE) { saveSpot() }
        ui.post(walkTick)
    }

    private fun stopWalk() {
        if (!walkOn) return
        walkOn = false
        ui.removeCallbacks(walkTick)
        try { tone?.release() } catch (e: Exception) { }
        tone = null
        walkBtn.text = "ابدأ التجوال"
        walkBox.removeAllViews()
        line(walkBox, "امشِ في البيت ببطء: كلما أسرعت النغمات قويت الإشارة. اجلس أو ضع الراوتر في أسرع مكان.", gray)
    }

    private fun saveSpot() {
        val r = currentRssi()
        if (r == null) { Toast.makeText(this, "غير متصل بوايفاي", Toast.LENGTH_SHORT).show(); return }
        askText("اسم هذا المكان", "مثال: غرفة النوم", Store.room(this), false) {
            Store.setRoom(this, it)
            updateRoomChip()
            Store.addTest(this, TestEntry(System.currentTimeMillis(), it, -1.0, -1.0, r, -1))
            Toast.makeText(this, "تم الحفظ: $r dBm", Toast.LENGTH_SHORT).show()
        }
    }

    // ───────────── فحص القنوات ─────────────

    private fun chOf(f: Int): Int = when {
        f in 2412..2472 -> (f - 2407) / 5
        f == 2484 -> 14
        else -> 0
    }

    private fun scanChannels() {
        chBox.removeAllViews()
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            line(chBox, "يطلب أندرويد إذن الموقع لقراءة قائمة الشبكات المجاورة (التطبيق لا يستخدم موقعك). اسمح به ثم سيبدأ الفحص.", colors[1])
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 7)
            return
        }
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        val locOn = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) lm.isLocationEnabled else true
        if (!locOn) {
            line(chBox, "فعّل خدمة الموقع (GPS) من الإعدادات ثم أعد المحاولة — أندرويد لا يعرض الشبكات المجاورة بدونها.", colors[1])
            return
        }
        line(chBox, "جارٍ فحص الشبكات المجاورة…", gray)
        val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
        @Suppress("DEPRECATION")
        val started = wm.startScan()
        if (!started) { /* أندرويد يحدّ عدد مرات الفحص؛ سنعرض آخر نتائج متاحة */ }
        ui.postDelayed({ showChannels() }, 4000)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        val granted = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
        if (requestCode == 7 && granted) scanChannels()
        if (requestCode == 9) startMonitor() // تعمل المراقبة حتى لو رُفض الإشعار (لكن بدون تنبيهات ظاهرة)
    }

    @Suppress("DEPRECATION")
    private fun showChannels() {
        chBox.removeAllViews()
        val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
        val res: List<ScanResult> = try { wm.scanResults } catch (e: SecurityException) { emptyList() }
        if (res.isEmpty()) {
            line(chBox, "لم تظهر نتائج. تأكد أن الموقع مفعّل وأعد المحاولة بعد دقيقة (أندرويد يحدّ عدد مرات الفحص).", colors[1])
            return
        }
        val info = wm.connectionInfo
        val myBssid = info?.bssid
        val myCh = if (info != null) chOf(info.frequency) else 0
        val others = res.filter { chOf(it.frequency) > 0 && it.BSSID != myBssid }

        if (info != null && myCh == 0 && info.frequency > 4900) {
            line(chBox, "أنت الآن على نطاق 5 GHz — لا حاجة لتغيير القناة.", colors[3])
            return
        }

        fun score(c: Int): Double {
            var t = 0.0
            for (r in others) {
                val d = abs(chOf(r.frequency) - c)
                if (d < 5) t += (r.level + 100).coerceAtLeast(0) * (5 - d) / 5.0
            }
            return t
        }
        fun count(c: Int) = others.count { abs(chOf(it.frequency) - c) < 5 }
        fun level(sc: Double) = when { sc < 20 -> 3; sc < 80 -> 2; sc < 200 -> 1; else -> 0 }
        val names = arrayOf("ازدحام شديد", "ازدحام متوسط", "هادئة نسبيًا", "هادئة جدًا")

        if (myCh > 0) {
            val sc = score(myCh)
            line(chBox, "قناتك الحالية: $myCh — ${count(myCh)} شبكة مجاورة • ${names[level(sc)]}", colors[level(sc)])
        }
        val cands = intArrayOf(1, 6, 11)
        for (c in cands) {
            val sc = score(c)
            line(chBox, "قناة $c — ${count(c)} شبكة مجاورة • ${names[level(sc)]}", colors[level(sc)])
        }
        val best = cands.minByOrNull { score(it) } ?: 1
        val curScore = if (myCh > 0) score(myCh) else Double.MAX_VALUE
        val fine = myCh > 0 && (myCh == best || curScore <= score(best) * 1.2 + 10)
        if (fine) {
            line(chBox, "قناتك الحالية مناسبة — تغييرها لن يفيد كثيرًا ✓", colors[3])
        } else {
            val from = if (myCh > 0) " (بدل $myCh)" else ""
            line(chBox, "الأفضل لك: قناة $best$from", colors[3])
            line(chBox, "تغيير القناة يتم من الراوتر وليس من الهاتف: Wi-Fi ← Channel ← اختر $best ← احفظ. ويُفضّل عرض القناة 20 MHz.", gray)
            line(chBox, "افتح صفحة الراوتر الآن  ◀", blue) { openRouter() }
        }
    }

    private fun openRouter() {
        val g = NetProbe.findGateway(this)
        if (g == null) {
            Toast.makeText(this, "لم أجد عنوان الراوتر — تأكد أنك متصل بالوايفاي", Toast.LENGTH_LONG).show()
            return
        }
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("http://$g"))) } catch (e: Exception) { }
    }

    // ───────────── اختبار DNS ─────────────

    private val dnsList = listOf(
        Dns("Cloudflare", "1.1.1.1", "one.one.one.one"),
        Dns("Google", "8.8.8.8", "dns.google"),
        Dns("Quad9", "9.9.9.9", "dns.quad9.net"),
        Dns("AdGuard (يحجب الإعلانات)", "94.140.14.14", "dns.adguard-dns.com"),
        Dns("OpenDNS", "208.67.222.222", null)
    )
    private val benchNames = arrayOf("google.com", "youtube.com", "facebook.com", "wikipedia.org", "amazon.com", "whatsapp.com")

    private fun systemDns(): String? {
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val n = cm.activeNetwork ?: return null
        val lp = cm.getLinkProperties(n) ?: return null
        for (d in lp.dnsServers) if (d is Inet4Address) return d.hostAddress
        return null
    }

    private fun dnsQuery(server: String, domain: String, timeout: Int): Int {
        val id = (Math.random() * 65535).toInt()
        val out = java.io.ByteArrayOutputStream()
        out.write(id shr 8); out.write(id and 0xFF)
        out.write(0x01); out.write(0x00)
        out.write(0); out.write(1)
        for (i in 0 until 6) out.write(0)
        for (part in domain.split(".")) { out.write(part.length); out.write(part.toByteArray()) }
        out.write(0)
        out.write(0); out.write(1); out.write(0); out.write(1)
        val q = out.toByteArray()
        val t0 = SystemClock.elapsedRealtime()
        return try {
            java.net.DatagramSocket().use { sock ->
                sock.soTimeout = timeout
                sock.send(java.net.DatagramPacket(q, q.size, InetAddress.getByName(server), 53))
                val buf = ByteArray(512)
                sock.receive(java.net.DatagramPacket(buf, buf.size))
                val ms = (SystemClock.elapsedRealtime() - t0).toInt()
                val okId = (buf[0].toInt() and 0xFF) == (id shr 8) && (buf[1].toInt() and 0xFF) == (id and 0xFF)
                val rcode = buf[3].toInt() and 0x0F
                if (okId && rcode == 0) ms else -1
            }
        } catch (e: Exception) { -1 }
    }

    private fun benchDns() {
        if (dnsBusy) return
        dnsBusy = true
        dnsBox.removeAllViews()
        line(dnsBox, "جارٍ اختبار الخوادم… (حوالي 10 ثوانٍ)", gray)
        val servers = ArrayList<Dns>(dnsList)
        val sys = systemDns()
        if (sys != null && dnsList.none { it.ip == sys }) servers.add(0, Dns("DNS الحالي (الراوتر/شركة الإنترنت)", sys, null))
        Thread {
            val results = java.util.Collections.synchronizedList(ArrayList<DnsRes>())
            val ts = servers.map { sv ->
                Thread {
                    val ok = ArrayList<Int>()
                    var fails = 0
                    for (n in benchNames) {
                        if (dnsQuery(sv.ip, n, 1200) < 0) { // المحاولة الأولى للإحماء فقط
                            fails++
                            if (fails >= 2 && ok.isEmpty()) break
                            continue
                        }
                        val r = dnsQuery(sv.ip, n, 1200)
                        if (r >= 0) ok.add(r) else fails++
                    }
                    ok.sort()
                    val med = if (ok.isEmpty()) -1 else ok[ok.size / 2]
                    results.add(DnsRes(sv.label, sv.host, med))
                }.also { it.start() }
            }
            for (t in ts) t.join(15000)
            val snapshot = ArrayList<DnsRes>(results)
            ui.post { showDns(snapshot, sys) }
        }.start()
    }

    private fun showDns(res: List<DnsRes>, sys: String?) {
        dnsBusy = false
        dnsBox.removeAllViews()
        val ok = res.filter { it.ms >= 0 }.sortedBy { it.ms }
        if (ok.isEmpty()) {
            line(dnsBox, "لم يستجب أي خادم — قد تكون الشبكة تحجب DNS الخارجي أو لا يوجد إنترنت.", colors[0])
            return
        }
        val cur = if (sys != null) res.firstOrNull { it.label.startsWith("DNS الحالي") } else null
        val best = ok.firstOrNull { it.host != null }
        val curMs = cur?.ms ?: -1
        if (best != null) {
            if (curMs >= 0 && best.ms >= curMs * 0.8 - 5) {
                line(dnsBox, "DNS الحالي جيد ($curMs ms) — لا حاجة للتغيير ✓", colors[3])
            } else {
                val gain = if (curMs >= 0) " — أسرع من الحالي بـ ${curMs - best.ms} ms" else ""
                line(dnsBox, "الأفضل: ${best.label} (${best.ms} ms)$gain", colors[3])
            }
        }
        for (r in ok) {
            val tag = if (r.host == null) " • لا يدعم DNS الخاص" else ""
            line(dnsBox, "${r.label} — ${r.ms} ms$tag", Color.WHITE) { applyDns(r) }
        }
        for (r in res.filter { it.ms < 0 }) line(dnsBox, "${r.label} — لا يستجيب", colors[0])
        line(dnsBox, "اضغط على أي خادم لتطبيقه. القياس لأشهر المواقع (مخزّنة مؤقتًا).", gray)
    }

    private fun applyDns(r: DnsRes) {
        val host = r.host
        if (host == null) {
            AlertDialog.Builder(this)
                .setTitle(r.label)
                .setMessage("هذا الخادم لا يدعم «DNS الخاص». لاستخدامه: إعدادات الوايفاي ← اضغط مطولًا على شبكتك ← تعديل ← خيارات متقدمة ← إعدادات IP: ثابت ← ثم اكتب عنوان DNS. أو غيّره من صفحة الراوتر ليستفيد جميع الأجهزة.")
                .setPositiveButton("حسنًا", null)
                .show()
            return
        }
        try {
            (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager)
                .setPrimaryClip(ClipData.newPlainText("dns", host))
        } catch (e: Exception) { }
        AlertDialog.Builder(this)
            .setTitle("تفعيل ${r.label}")
            .setMessage("نسخنا الاسم:\n$host\n\n١- اضغط «فتح الإعدادات»\n٢- ابحث في الإعدادات عن «DNS الخاص» (Private DNS)\n٣- اختر «اسم مضيف موفر DNS الخاص»\n٤- الصق الاسم واحفظ")
            .setPositiveButton("فتح الإعدادات") { _, _ ->
                try { startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS)) } catch (e: Exception) { }
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    // ───────────── السجل ─────────────

    private fun toggleMonitor() {
        if (Store.monitorOn(this)) {
            stopService(Intent(this, MonitorService::class.java))
            Store.setMonitorOn(this, false)
            renderHistory()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 9)
            return
        }
        startMonitor()
    }

    private fun startMonitor() {
        try { startForegroundService(Intent(this, MonitorService::class.java)) } catch (e: Exception) { }
        Store.setMonitorOn(this, true)
        renderHistory()
    }

    private fun renderHistory() {
        pgHist.removeAllViews()

        // الباقة
        val planBox = card(pgHist, "باقة الإنترنت")
        val plan = Store.plan(this)
        val planText = if (plan > 0f) "سرعة باقتي: ${num(plan.toDouble())} Mbps  ✎" else "حدّد سرعة باقتك لمعرفة نسبة ما تحصل عليه ✎"
        line(planBox, planText, Color.WHITE) {
            askText("سرعة باقتك (Mbps)", "مثال: 100", if (plan > 0f) num(plan.toDouble()) else "", true) {
                Store.setPlan(this, it.toFloatOrNull() ?: 0f)
                renderHistory()
            }
        }
        line(planBox, "ملاحظة: وايفاي 2.4 GHz نادرًا يعطي أكثر من 50–70 Mbps حتى لو باقتك أعلى.", gray)

        // المراقبة والانقطاعات
        val on = Store.monitorOn(this)
        val mon = section(pgHist, "مراقبة الانقطاعات", if (on) "إيقاف المراقبة" else "تشغيل المراقبة في الخلفية") { toggleMonitor() }
        if (on) {
            line(mon.box, "المراقبة تعمل ✓ (قد يوقفها النظام عند توفير الطاقة الشديد)", colors[3])
        } else {
            line(mon.box, "تعمل في الخلفية مع إشعار دائم، وتسجّل كل انقطاع (الوقت والمدة والسبب) وتنبّهك عند الانقطاع أو ضعف الإشارة. مفيدة كدليل لشركة الإنترنت.", gray)
        }
        val outs = Store.outages(this)
        val dayAgo = System.currentTimeMillis() - 86_400_000L
        val recent = outs.filter { it.start >= dayAgo }
        if (outs.isEmpty()) {
            line(mon.box, "لا توجد انقطاعات مسجّلة", gray)
        } else {
            var totalMs = 0L
            for (o in recent) totalMs += o.durMs
            line(mon.box, "آخر 24 ساعة: ${recent.size} انقطاع • إجمالي ${fmtDur(totalMs)}", Color.WHITE)
            for (o in outs.takeLast(12).reversed()) {
                line(mon.box, df.format(Date(o.start)) + " — " + fmtDur(o.durMs) + " — " + o.cause,
                    colors[if (o.durMs >= 60_000) 0 else 1])
            }
            line(mon.box, "مشاركة سجل الانقطاعات", blue) { shareOutages(outs) }
            line(mon.box, "مسح السجل", colors[0]) {
                AlertDialog.Builder(this)
                    .setMessage("مسح كل سجل الانقطاعات؟")
                    .setPositiveButton("مسح") { _, _ -> Store.clearOutages(this); renderHistory() }
                    .setNegativeButton("إلغاء", null)
                    .show()
            }
        }

        // المقارنة حسب المكان
        val tests = Store.tests(this)
        val roomBox = card(pgHist, "المقارنة حسب المكان")
        val byRoom = tests.groupBy { if (it.room.isEmpty()) "بدون اسم" else it.room }
        if (byRoom.isEmpty()) {
            line(roomBox, "لا توجد قياسات بعد — أجرِ اختبار سرعة أو احفظ قراءة من وضع التجوال (تبويب «أدوات»).", gray)
        }
        for ((room, list) in byRoom) {
            val dls = list.filter { it.dl > 0 }.map { it.dl }
            val uls = list.filter { it.ul > 0 }.map { it.ul }
            val rs = list.filter { it.rssi < 0 }.map { it.rssi }
            val parts = ArrayList<String>()
            if (dls.isNotEmpty()) parts.add("تحميل " + num(dls.average()))
            if (uls.isNotEmpty()) parts.add("رفع " + num(uls.average()))
            if (rs.isNotEmpty()) parts.add("إشارة " + rs.average().toInt() + " dBm")
            line(roomBox, room + " — " + parts.joinToString(" • ") + " (" + list.size + ")", Color.WHITE)
        }

        // آخر القياسات
        if (tests.isNotEmpty()) {
            val recBox = card(pgHist, "آخر القياسات")
            for (t in tests.takeLast(8).reversed()) {
                val parts = ArrayList<String>()
                if (t.dl > 0) parts.add("تحميل " + num(t.dl))
                if (t.ul > 0) parts.add("رفع " + num(t.ul))
                if (t.rssi < 0) parts.add(t.rssi.toString() + " dBm")
                val where = if (t.room.isEmpty()) "" else " • " + t.room
                line(recBox, df.format(Date(t.ts)) + where + " — " + parts.joinToString(" / "), gray)
            }
        }
    }

    private fun shareOutages(outs: List<Outage>) {
        val sb = StringBuilder("سجل انقطاعات الإنترنت\n\n")
        for (o in outs.reversed()) {
            sb.append(df.format(Date(o.start))).append(" — ").append(fmtDur(o.durMs)).append(" — ").append(o.cause).append("\n")
        }
        shareText(sb.toString(), "مشاركة السجل")
    }

    private fun shareText(text: String, title: String) {
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }
        startActivity(Intent.createChooser(i, title))
    }

    private fun shareReport() {
        val sb = StringBuilder("تقرير جودة الوايفاي\n")
        sb.append(verdict.text).append("\n").append(diag.text).append("\n\n")
        for (r in rows) {
            sb.append("• ").append(r.title).append(": ").append(r.value.text)
            if (r.note.text.isNotEmpty()) sb.append(" — ").append(r.note.text)
            sb.append("\n")
        }
        shareText(sb.toString(), "مشاركة التقرير")
    }
}
