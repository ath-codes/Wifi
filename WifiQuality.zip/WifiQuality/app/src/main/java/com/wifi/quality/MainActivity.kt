package com.wifi.quality

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.pm.PackageManager
import android.location.LocationManager
import android.net.Uri
import android.net.wifi.ScanResult
import android.provider.Settings
import android.widget.Toast
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.net.ConnectException
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.abs

class MainActivity : Activity() {

    private class Row(val title: String, val value: TextView, val note: TextView)
    private class St(val avg: Int, val loss: Int, val jit: Int)
    private class Dns(val label: String, val ip: String, val host: String?)
    private class DnsRes(val label: String, val host: String?, val ms: Int)

    // رسم بياني بسيط لزمن الاستجابة (الراوتر + الإنترنت)
    private class Graph(c: Context, private val maxN: Int) : View(c) {
        private var a: List<Int> = emptyList()
        private var b: List<Int> = emptyList()
        private val pa = line(0xFF4CAF50.toInt())
        private val pb = line(0xFF4DA3FF.toInt())
        private val pl = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFF44336.toInt(); strokeWidth = 5f }
        private val pg = Paint().apply { color = 0xFF2C3442.toInt(); strokeWidth = 2f }
        private val pt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF6B7587.toInt(); textSize = 26f }

        private fun line(col: Int) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = col; strokeWidth = 4f; style = Paint.Style.STROKE; strokeJoin = Paint.Join.ROUND
        }

        fun setData(x: List<Int>, y: List<Int>) { a = x; b = y; invalidate() }

        override fun onDraw(cv: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            var mx = 100
            for (v in a) if (v > mx) mx = v
            for (v in b) if (v > mx) mx = v
            if (mx > 400) mx = 400
            cv.drawLine(0f, h - 6f, w, h - 6f, pg)
            cv.drawLine(0f, h / 2, w, h / 2, pg)
            cv.drawText("$mx ms", 4f, 24f, pt)
            series(cv, a, pa, w, h, mx)
            series(cv, b, pb, w, h, mx)
        }

        private fun series(cv: Canvas, s: List<Int>, p: Paint, w: Float, h: Float, mx: Int) {
            if (s.isEmpty()) return
            val step = w / (maxN - 1)
            val path = Path()
            var open = false
            for (i in s.indices) {
                val x = w - (s.size - 1 - i) * step
                val v = s[i]
                if (v < 0) {
                    cv.drawLine(x, h - 6f, x, h - 40f, pl)
                    open = false
                    continue
                }
                val y = h - 6f - (minOf(v, mx).toFloat() / mx) * (h - 14f)
                if (!open) { path.moveTo(x, y); open = true } else path.lineTo(x, y)
            }
            cv.drawPath(path, p)
        }
    }

    private val ui = Handler(Looper.getMainLooper())
    private val maxN = 80
    private val netG = ArrayDeque<Int>()      // للرسم البياني (-1 = فشل)
    private val gwG = ArrayDeque<Int>()
    private val netS = ArrayDeque<Int>()      // للإحصاءات (آخر 20) — تتجمد أثناء اختبار السرعة
    private val gwS = ArrayDeque<Int>()
    private val dnsS = ArrayDeque<Int>()
    private val loadSamples = ArrayList<Int>() // الاستجابة أثناء التحميل/الرفع
    private var idleAvg = -1

    @Volatile private var alive = false
    @Volatile private var gen = 0
    @Volatile private var gwPort = 80
    @Volatile private var testing = false
    private val threads = ArrayList<Thread>()
    private val rows = ArrayList<Row>()

    private lateinit var chBox: LinearLayout
    private lateinit var dnsBox: LinearLayout
    private var dnsBusy = false
    private lateinit var verdict: TextView
    private lateinit var diag: TextView
    private lateinit var graph: Graph
    private lateinit var testBtn: TextView
    private lateinit var signal: Row
    private lateinit var speed: Row
    private lateinit var band: Row
    private lateinit var router: Row
    private lateinit var ping: Row
    private lateinit var jitter: Row
    private lateinit var loss: Row
    private lateinit var dns: Row
    private lateinit var dl: Row
    private lateinit var ul: Row
    private lateinit var load: Row

    private val colors = intArrayOf(0xFFF44336.toInt(), 0xFFFFC107.toInt(), 0xFF8BC34A.toInt(), 0xFF4CAF50.toInt())
    private val testLabel = "اختبر السرعة (تحميل + رفع)"

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(16), dp(36), dp(16), dp(16))
        }
        verdict = TextView(this).apply {
            textSize = 28f; typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            setPadding(0, dp(8), 0, dp(6)); text = "…"
        }
        root.addView(verdict)
        diag = TextView(this).apply {
            textSize = 15f; gravity = Gravity.CENTER; setTextColor(0xFF9AA4B5.toInt())
            setPadding(dp(8), 0, dp(8), dp(18)); text = "جارٍ التحليل…"
        }
        root.addView(diag)

        graphCard(root)

        signal = row(root, "قوة الإشارة")
        router = row(root, "الاتصال بالراوتر (داخل البيت)")
        ping = row(root, "الاتصال بالإنترنت (Ping)")
        jitter = row(root, "الثبات (Jitter)")
        loss = row(root, "فقدان الحزم")
        dns = row(root, "سرعة DNS (فتح المواقع)")
        speed = row(root, "سرعة الربط")
        band = row(root, "النطاق")
        dl = row(root, "سرعة التحميل")
        ul = row(root, "سرعة الرفع")
        load = row(root, "الاستجابة أثناء التحميل")
        set(dl, "—", "اضغط الزر للقياس", 1)
        set(ul, "—", "اضغط الزر للقياس", 1)
        set(load, "—", "تُقاس أثناء اختبار السرعة", 1)
        set(dns, "—", "جارٍ القياس…", 1)

        chBox = section(root, "فحص قنوات الوايفاي (2.4 GHz)", "افحص القنوات المجاورة") { scanChannels() }
        line(chBox, "يحدد أقل القنوات ازدحامًا ويقترح أفضلها", 0xFF9AA4B5.toInt())
        dnsBox = section(root, "أسرع DNS", "اختبر خوادم DNS") { benchDns() }
        line(dnsBox, "يقارن خوادم DNS المشهورة ويقترح الأسرع", 0xFF9AA4B5.toInt())

        testBtn = button(testLabel, 0xFF2563EB.toInt()) { runSpeedTest(it) }
        root.addView(testBtn, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        val share = button("مشاركة التقرير", 0xFF374151.toInt()) { shareReport() }
        root.addView(share, LinearLayout.LayoutParams(-1, -2))

        setContentView(ScrollView(this).apply {
            setBackgroundColor(0xFF0F131A.toInt()); addView(root)
        })
    }

    private fun button(label: String, color: Int, click: (TextView) -> Unit): TextView =
        TextView(this).apply {
            text = label; textSize = 17f; typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            setPadding(0, dp(14), 0, dp(14))
            background = GradientDrawable().apply { setColor(color); cornerRadius = dp(14).toFloat() }
            setOnClickListener { click(this) }
        }

    private fun cardBg() = GradientDrawable().apply { setColor(0xFF1E2430.toInt()); cornerRadius = dp(14).toFloat() }

    private fun graphCard(parent: LinearLayout) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = cardBg()
        }
        card.addView(TextView(this).apply {
            text = "زمن الاستجابة خلال آخر دقيقة"; textSize = 13f; setTextColor(0xFF9AA4B5.toInt())
        })
        graph = Graph(this, maxN)
        card.addView(graph, LinearLayout.LayoutParams(-1, dp(110)).apply { topMargin = dp(8) })
        val lg = LinearLayout(this).apply { gravity = Gravity.CENTER }
        lg.addView(TextView(this).apply { text = "● الراوتر"; textSize = 13f; setTextColor(0xFF4CAF50.toInt()) })
        lg.addView(TextView(this).apply {
            text = "● الإنترنت"; textSize = 13f; setTextColor(0xFF4DA3FF.toInt()); setPadding(dp(16), 0, 0, 0)
        })
        lg.addView(TextView(this).apply {
            text = "| خط أحمر = فقدان"; textSize = 13f; setTextColor(0xFFF44336.toInt()); setPadding(dp(16), 0, 0, 0)
        })
        card.addView(lg)
        parent.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
    }

    private fun row(parent: LinearLayout, title: String): Row {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = cardBg()
        }
        card.addView(TextView(this).apply { text = title; textSize = 13f; setTextColor(0xFF9AA4B5.toInt()) })
        val line = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val v = TextView(this).apply { textSize = 24f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE) }
        val n = TextView(this).apply { textSize = 16f; setPadding(dp(12), 0, 0, 0) }
        line.addView(v); line.addView(n); card.addView(line)
        parent.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        return Row(title, v, n).also { rows.add(it) }
    }

    private fun set(r: Row, value: String, note: String, lv: Int) {
        r.value.text = value
        r.note.text = note
        r.note.setTextColor(colors[lv])
    }

    // ───────────── دورة الحياة والقياس المستمر ─────────────

    override fun onStart() {
        super.onStart()
        alive = true
        val my = ++gen
        loop(my, 700) { val ms = pingGateway(); ui.post { onSample(true, ms) } }
        loop(my, 700) { val ms = pingNet(); ui.post { onSample(false, ms) } }
        loop(my, 6000) { val ms = dnsMs(); ui.post { onDns(ms) } }
    }

    override fun onStop() {
        super.onStop()
        alive = false
        for (t in threads) t.interrupt()
        threads.clear()
    }

    private fun loop(my: Int, period: Long, body: () -> Unit) {
        val t = Thread {
            while (alive && my == gen) {
                val t0 = SystemClock.elapsedRealtime()
                try { body() } catch (e: Exception) { }
                val rest = period - (SystemClock.elapsedRealtime() - t0)
                if (rest > 0) try { Thread.sleep(rest) } catch (e: InterruptedException) { }
            }
        }
        threads.add(t)
        t.start()
    }

    // يرجع الزمن بالميلي ثانية، أو -1 عند الفشل. "رفض الاتصال" يُعد استجابة صحيحة (الجهاز ردّ).
    private fun tcpPing(host: String, port: Int, timeout: Int): Int {
        val t0 = SystemClock.elapsedRealtime()
        return try {
            Socket().use { it.connect(InetSocketAddress(host, port), timeout) }
            (SystemClock.elapsedRealtime() - t0).toInt()
        } catch (e: ConnectException) {
            if (e.message?.contains("refused", true) == true) (SystemClock.elapsedRealtime() - t0).toInt() else -1
        } catch (e: Exception) {
            -1
        }
    }

    private fun findGateway(): String? {
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val n = cm.activeNetwork ?: return null
        val caps = cm.getNetworkCapabilities(n) ?: return null
        if (!caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) return null
        val lp = cm.getLinkProperties(n) ?: return null
        for (r in lp.routes) {
            val g = r.gateway
            if (r.isDefaultRoute && g is Inet4Address) return g.hostAddress
        }
        return null
    }

    // -2 = لا يوجد راوتر (غير متصل بوايفاي)
    private fun pingGateway(): Int {
        val g = findGateway() ?: return -2
        var r = tcpPing(g, gwPort, 800)
        if (r >= 0) return r
        for (p in intArrayOf(80, 53, 443, 8080)) {
            if (p == gwPort) continue
            r = tcpPing(g, p, 300)
            if (r >= 0) { gwPort = p; return r }
        }
        return -1
    }

    private fun pingNet(): Int {
        var r = tcpPing("1.1.1.1", 443, 1500)
        if (r < 0) r = tcpPing("8.8.8.8", 443, 1000)
        return r
    }

    // زمن البحث عن اسم جديد غير مخزّن (يقيس سرعة خادم DNS الفعلي)
    private fun dnsMs(): Int {
        val t0 = SystemClock.elapsedRealtime()
        try { InetAddress.getByName("x" + System.nanoTime() + ".google.com") } catch (e: Exception) { }
        return (SystemClock.elapsedRealtime() - t0).toInt()
    }

    private fun onDns(ms: Int) {
        if (testing) return
        if ((netG.lastOrNull() ?: -1) < 0) return // لا إنترنت أصلًا — لا معنى للقياس
        dnsS.addLast(ms)
        if (dnsS.size > 3) dnsS.removeFirst()
        refresh()
    }

    private fun onSample(isGw: Boolean, ms: Int) {
        if (ms == -2) { // غير متصل بوايفاي
            gwG.clear(); gwS.clear()
            refresh()
            return
        }
        val g = if (isGw) gwG else netG
        g.addLast(ms)
        if (g.size > maxN) g.removeFirst()
        if (testing) {
            if (!isGw) loadSamples.add(ms)
        } else {
            val s = if (isGw) gwS else netS
            s.addLast(ms)
            if (s.size > 20) s.removeFirst()
        }
        graph.setData(gwG.toList(), netG.toList())
        refresh()
    }

    // ───────────── اختبار السرعة ─────────────

    private fun mbps(bytes: Long, ms: Long) = bytes * 8.0 / 1_000_000 / (ms / 1000.0)
    private fun fmt(m: Double) = String.format(Locale.US, "%.1f Mbps", m)

    private fun isOnWifi(): Boolean {
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val n = cm.activeNetwork ?: return false
        return cm.getNetworkCapabilities(n)?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
    }

    private fun runSpeedTest(btn: TextView) {
        if (testing) return
        if (!isOnWifi()) {
            set(dl, "—", "الاختبار يعمل على الوايفاي فقط حفاظًا على باقة البيانات", 0)
            return
        }
        testing = true
        loadSamples.clear()
        idleAvg = if (netS.isEmpty()) -1 else stat(netS).avg
        btn.text = "جارٍ القياس…"; btn.alpha = 0.6f
        set(dl, "…", "جارٍ قياس التحميل", 1)
        set(ul, "—", "بانتظار انتهاء التحميل", 1)
        set(load, "…", "جارٍ القياس", 1)
        Thread {
            try {
                val d = measureDown()
                ui.post { showDown(d) }
                SystemClock.sleep(400)
                ui.post { set(ul, "…", "جارٍ قياس الرفع", 1) }
                val u = measureUp()
                ui.post { showUp(u) }
            } catch (e: Exception) {
            } finally {
                ui.post {
                    showLoad()
                    testing = false
                    btn.text = testLabel; btn.alpha = 1f
                }
            }
        }.start()
    }

    private val lastErr = java.util.concurrent.atomic.AtomicReference("")
    private val downUrls = arrayOf(
        "https://speed.cloudflare.com/__down?bytes=25000000",
        "https://cachefly.cachefly.net/50mb.test",
        "https://proof.ovh.net/files/100Mb.dat"
    )

    // 4 اتصالات متوازية تعيد الطلب باستمرار حتى انتهاء الوقت، وتنتقل لمصدر بديل إن فشل الأول
    private fun measureDown(): Double {
        val total = AtomicLong(0)
        val stop = AtomicBoolean(false)
        lastErr.set("")
        repeat(4) {
            Thread {
                var u = 0
                while (!stop.get() && u < downUrls.size) {
                    var c: HttpURLConnection? = null
                    val before = total.get()
                    try {
                        c = URL(downUrls[u]).openConnection() as HttpURLConnection
                        c.connectTimeout = 5000; c.readTimeout = 5000
                        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) WifiQuality/1.2")
                        c.setRequestProperty("Accept-Encoding", "identity")
                        val code = c.responseCode
                        if (code != 200) {
                            lastErr.set("HTTP $code")
                            u++
                            continue
                        }
                        c.inputStream.use { s ->
                            val buf = ByteArray(65536)
                            while (!stop.get()) {
                                val n = s.read(buf)
                                if (n < 0) break
                                total.addAndGet(n.toLong())
                            }
                        }
                        if (total.get() == before) u++
                    } catch (e: Exception) {
                        lastErr.set(e.javaClass.simpleName)
                        if (total.get() == before) u++
                    } finally { c?.disconnect() }
                }
            }.start()
        }
        return watch(total, stop, dl, 8000)
    }

    private fun measureUp(): Double {
        val sent = AtomicLong(0)
        val stop = AtomicBoolean(false)
        lastErr.set("")
        repeat(3) {
            Thread {
                val body = ByteArray(65536)
                while (!stop.get()) {
                    var c: HttpURLConnection? = null
                    try {
                        val size = 10_000_000
                        c = URL("https://speed.cloudflare.com/__up").openConnection() as HttpURLConnection
                        c.requestMethod = "POST"; c.doOutput = true
                        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) WifiQuality/1.2")
                        c.connectTimeout = 4000; c.readTimeout = 8000
                        c.setFixedLengthStreamingMode(size)
                        c.outputStream.use { o ->
                            var left = size
                            while (!stop.get() && left > 0) {
                                val n = minOf(body.size, left)
                                o.write(body, 0, n)
                                left -= n
                                sent.addAndGet(n.toLong())
                            }
                        }
                        if (!stop.get()) {
                            val code = c.responseCode
                            if (code >= 400) { lastErr.set("HTTP $code"); SystemClock.sleep(300) }
                        }
                    } catch (e: Exception) {
                        lastErr.set(e.javaClass.simpleName)
                        if (sent.get() == 0L) SystemClock.sleep(300)
                    } finally { c?.disconnect() }
                }
            }.start()
        }
        return watch(sent, stop, ul, 6500)
    }

    // يراقب العدّاد، يعرض التقدم، ويرجع السرعة المستقرة (أو -1 عند الفشل)
    private fun watch(counter: AtomicLong, stop: AtomicBoolean, target: Row, limitMs: Long): Double {
        val t0 = SystemClock.elapsedRealtime()
        var warmBytes = -1L
        var warmT = 0L
        var lastUi = 0L
        while (true) {
            SystemClock.sleep(150)
            val now = SystemClock.elapsedRealtime()
            val el = now - t0
            val tot = counter.get()
            if (warmBytes < 0 && el >= 1500) { warmBytes = tot; warmT = now }
            if (warmBytes >= 0 && now - lastUi > 400 && now > warmT) {
                lastUi = now
                val m = mbps(tot - warmBytes, now - warmT)
                ui.post { set(target, fmt(m), "جارٍ القياس", 1) }
            }
            if (el >= limitMs || tot > 300_000_000L) break
            if (el > 5000 && tot == 0L) break
        }
        stop.set(true)
        val end = SystemClock.elapsedRealtime()
        val got = counter.get() - warmBytes
        if (warmBytes < 0 || got < 50_000 || end <= warmT) return -1.0
        return mbps(got, end - warmT)
    }

    private fun failMsg(base: String): String {
        val e = lastErr.get()
        return if (e.isEmpty()) base else "$base ($e)"
    }

    private fun showDown(m: Double) {
        if (m < 0) { set(dl, "—", failMsg("فشل القياس — تحقق من الإنترنت"), 0); return }
        val lv = when { m >= 50 -> 3; m >= 25 -> 2; m >= 5 -> 1; else -> 0 }
        set(dl, fmt(m), arrayOf("بطيئة", "للتصفح فقط", "جيدة للبث HD", "ممتازة للبث 4K")[lv], lv)
    }

    private fun showUp(m: Double) {
        if (m < 0) { set(ul, "—", failMsg("فشل قياس الرفع"), 0); return }
        val lv = when { m >= 20 -> 3; m >= 5 -> 2; m >= 1.5 -> 1; else -> 0 }
        set(ul, fmt(m), arrayOf("ضعيفة", "بطيئة لرفع الملفات", "جيدة للمكالمات المرئية", "ممتازة")[lv], lv)
    }

    // الاستجابة تحت الضغط: إن ارتفعت كثيرًا فالراوتر يختنق عند الاستهلاك (Bufferbloat)
    private fun showLoad() {
        val ok = loadSamples.filter { it >= 0 }
        if (ok.isEmpty()) { set(load, "—", "لم تُسجَّل قياسات", 1); return }
        val avg = ok.average().toInt()
        val lv = when { avg < 60 -> 3; avg < 120 -> 2; avg < 250 -> 1; else -> 0 }
        val extra = if (idleAvg >= 0 && avg > idleAvg) " (+${avg - idleAvg})" else ""
        set(load, "$avg ms$extra",
            arrayOf("يتأثر بشدة — المكالمات والألعاب تتقطع أثناء التحميل", "يتأثر بوضوح عند الضغط", "مقبول", "ممتاز — لا يتأثر بالتحميل")[lv], lv)
    }

    // ───────────── التحليل والعرض ─────────────

    private fun stat(s: Collection<Int>): St {
        val ok = s.filter { it >= 0 }
        val loss = if (s.isEmpty()) 0 else (s.size - ok.size) * 100 / s.size
        val avg = if (ok.isEmpty()) -1 else ok.average().toInt()
        val jit = if (ok.size < 2) 0 else ok.zipWithNext { a, c -> abs(a - c) }.average().toInt()
        return St(avg, loss, jit)
    }

    // يحدد أين المشكلة: الوايفاي، الراوتر/الإنترنت، أم DNS
    private fun diagnose(wifi: Boolean, sigLevel: Int, gw: St?, net: St?, dnsAvg: Int): Pair<String, Int> {
        if (!wifi) return "أنت غير متصل بوايفاي — القياس هنا للإنترنت العام فقط" to 0
        if (net == null) return "جارٍ التحليل…" to 1
        val gwBad = gw != null && (gw.avg < 0 || gw.loss >= 15 || gw.avg > 80)
        val netDown = net.avg < 0 || net.loss >= 30
        val netBad = net.loss >= 10 || net.avg >= 120 || net.jit >= 60
        return when {
            gwBad -> "المشكلة في الوايفاي نفسه: الاتصال بين جهازك والراوتر ضعيف أو مزدحم. اقترب من الراوتر أو استخدم نطاق 5 GHz." to 0
            netDown -> "الوايفاي سليم لكن الإنترنت منقطع أو متقطع — المشكلة من الراوتر أو شركة الإنترنت. جرّب إعادة تشغيل الراوتر." to 0
            netBad -> "الوايفاي سليم لكن الإنترنت بطيء أو غير مستقر — غالبًا من الخدمة أو بسبب استهلاك أجهزة أخرى للشبكة." to 1
            sigLevel == 0 -> "القياسات جيدة الآن لكن الإشارة ضعيفة — قد يسوء الاتصال إن ابتعدت أكثر عن الراوتر." to 1
            dnsAvg >= 300 -> "الإنترنت سريع لكن DNS بطيء. جرّب من إعدادات الهاتف ← DNS الخاص ← اكتب: dns.google" to 1
            else -> "كل شيء سليم ✓ الاتصال مناسب للبث والمكالمات والألعاب" to 3
        }
    }

    @Suppress("DEPRECATION")
    private fun refresh() {
        val levels = ArrayList<Int>()

        // الوايفاي
        val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
        val info = wm.connectionInfo
        val connected = wm.isWifiEnabled && info != null && info.rssi > -127 && info.rssi < 0
        var sigLevel = 0
        if (connected) {
            val r = info.rssi
            val ls = when { r >= -50 -> 3; r >= -60 -> 2; r >= -70 -> 1; else -> 0 }
            set(signal, "$r dBm", arrayOf("ضعيفة — اقترب من الراوتر", "متوسطة", "جيدة", "ممتازة")[ls], ls)
            levels.add(ls)
            sigLevel = ls

            val s = info.linkSpeed
            val ss = when { s >= 300 -> 3; s >= 100 -> 2; s >= 50 -> 1; else -> 0 }
            set(speed, "$s Mbps", arrayOf("بطيئة", "متوسطة", "جيدة", "سريعة")[ss], ss)

            val f = info.frequency
            val (bn, bs) = when {
                f < 3000 -> "2.4 GHz" to "مدى أبعد، أبطأ"
                f < 5900 -> "5 GHz" to "أسرع، مدى أقصر"
                else -> "6 GHz" to "الأسرع، مدى قصير"
            }
            val std = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                when (info.wifiStandard) { 4 -> "Wi-Fi 4"; 5 -> "Wi-Fi 5"; 6 -> "Wi-Fi 6"; 8 -> "Wi-Fi 7"; else -> "" }
            } else ""
            set(band, bn, if (std.isEmpty()) bs else "$bs • $std", if (f < 3000) 1 else 3)
        } else {
            set(signal, "—", "غير متصل بوايفاي", 0)
            set(speed, "—", "", 0)
            set(band, "—", "", 0)
            levels.add(0)
        }

        // الراوتر
        val gw = if (gwS.isEmpty()) null else stat(gwS)
        if (gw == null) {
            set(router, "—", if (connected) "جارٍ القياس…" else "غير متصل بوايفاي", if (connected) 1 else 0)
        } else {
            val la = when { gw.avg < 0 -> 0; gw.avg < 10 -> 3; gw.avg < 30 -> 2; gw.avg < 80 -> 1; else -> 0 }
            val ll = when { gw.loss >= 15 -> 0; gw.loss > 0 -> 1; else -> 3 }
            val lv = minOf(la, ll)
            val base = if (gw.avg < 0) "الراوتر لا يستجيب"
            else arrayOf("ضعيف — الوايفاي مزدحم أو بعيد", "متوسط", "جيد", "ممتاز")[la]
            set(router, if (gw.avg < 0) "—" else "${gw.avg} ms",
                if (gw.loss > 0 && gw.avg >= 0) "$base • فقدان ${gw.loss}%" else base, lv)
            levels.add(lv)
        }

        // الإنترنت: Ping / Jitter / فقدان
        val net = if (netS.isEmpty()) null else stat(netS)
        if (net != null) {
            val ls = when { net.loss == 0 -> 3; net.loss <= 10 -> 1; else -> 0 }
            set(loss, "${net.loss}%", arrayOf("فقدان كثير", "فقدان بسيط", "", "لا يوجد فقدان")[ls], ls)
            levels.add(ls)

            if (net.avg < 0) {
                set(ping, "—", "لا يوجد إنترنت", 0)
                set(jitter, "—", "", 0)
                levels.add(0)
            } else {
                val ps = when { net.avg < 30 -> 3; net.avg < 60 -> 2; net.avg < 120 -> 1; else -> 0 }
                set(ping, "${net.avg} ms", arrayOf("بطيء", "متوسط", "جيد للتصفح", "ممتاز للألعاب")[ps], ps)
                levels.add(ps)

                val js = when { net.jit < 10 -> 3; net.jit < 30 -> 2; net.jit < 60 -> 1; else -> 0 }
                set(jitter, "${net.jit} ms", arrayOf("متذبذب جدًا — المكالمات تتقطع", "متذبذب قليلًا", "مقبول", "مستقر")[js], js)
                levels.add(js)
            }
        }

        // DNS
        var dnsAvg = -1
        if (dnsS.isNotEmpty()) {
            dnsAvg = dnsS.average().toInt()
            val ds = when { dnsAvg < 120 -> 3; dnsAvg < 300 -> 2; dnsAvg < 700 -> 1; else -> 0 }
            set(dns, "$dnsAvg ms", arrayOf("بطيء جدًا — المواقع ستتأخر في الفتح", "بطيء", "مقبول", "سريع")[ds], ds)
            levels.add(ds)
        }

        if (net != null) {
            val v = levels.min()
            verdict.text = arrayOf("اتصالك ضعيف", "اتصالك متوسط", "اتصالك جيد", "اتصالك ممتاز")[v]
            verdict.setTextColor(colors[v])
        }
        val d = diagnose(connected, sigLevel, gw, net, dnsAvg)
        diag.text = d.first
        diag.setTextColor(if (d.second == 3) colors[3] else colors[d.second])
    }


    // ───────────── واجهة الأقسام ─────────────

    private fun section(parent: LinearLayout, title: String, label: String, click: () -> Unit): LinearLayout {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = cardBg()
        }
        card.addView(TextView(this).apply { text = title; textSize = 13f; setTextColor(0xFF9AA4B5.toInt()) })
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        card.addView(box, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        card.addView(button(label, 0xFF2563EB.toInt()) { click() },
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        parent.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        return box
    }

    private fun line(box: LinearLayout, msg: String, color: Int = Color.WHITE, onClick: (() -> Unit)? = null) {
        val t = TextView(this)
        t.text = msg
        t.textSize = 15f
        t.setTextColor(color)
        t.setPadding(0, dp(6), 0, dp(6))
        if (onClick != null) {
            t.setPadding(dp(12), dp(10), dp(12), dp(10))
            t.background = GradientDrawable().apply { setColor(0xFF2A3342.toInt()); cornerRadius = dp(10).toFloat() }
            t.setOnClickListener { onClick() }
            box.addView(t, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        } else {
            box.addView(t)
        }
    }

    // ───────────── فحص القنوات ─────────────

    private fun chOf(f: Int): Int = when {
        f in 2412..2472 -> (f - 2407) / 5
        f == 2484 -> 14
        else -> 0
    }

    private fun scanChannels() {
        chBox.removeAllViews()
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            line(chBox, "يطلب أندرويد إذن الموقع لقراءة قائمة الشبكات المجاورة (التطبيق لا يستخدم موقعك). اسمح به ثم سيبدأ الفحص.", colors[1])
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 7)
            return
        }
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        val locOn = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) lm.isLocationEnabled else true
        if (!locOn) {
            line(chBox, "فعّل خدمة الموقع (GPS) من الإعدادات ثم أعد المحاولة — أندرويد لا يعرض الشبكات المجاورة بدونها.", colors[1])
            return
        }
        line(chBox, "جارٍ فحص الشبكات المجاورة…", 0xFF9AA4B5.toInt())
        val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
        @Suppress("DEPRECATION")
        val started = wm.startScan()
        if (!started) { /* أندرويد يحدّ عدد مرات الفحص؛ سنعرض آخر نتائج متاحة */ }
        ui.postDelayed({ showChannels() }, 4000)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 7 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) scanChannels()
    }

    @Suppress("DEPRECATION")
    private fun showChannels() {
        chBox.removeAllViews()
        val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
        val res: List<ScanResult> = try { wm.scanResults } catch (e: SecurityException) { emptyList() }
        if (res.isEmpty()) {
            line(chBox, "لم تظهر نتائج. تأكد أن الموقع مفعّل وأعد المحاولة بعد دقيقة (أندرويد يحدّ عدد مرات الفحص).", colors[1])
            return
        }
        val info = wm.connectionInfo
        val myBssid = info?.bssid
        val myCh = if (info != null) chOf(info.frequency) else 0
        val others = res.filter { chOf(it.frequency) > 0 && it.BSSID != myBssid }

        if (info != null && myCh == 0 && info.frequency > 4900) {
            line(chBox, "أنت الآن على نطاق 5 GHz — لا حاجة لتغيير القناة.", colors[3])
            return
        }

        // التداخل: القنوات المتقاربة (أقل من 5 قنوات) تتداخل، والأقوى إشارة يؤثر أكثر
        fun score(c: Int): Double {
            var t = 0.0
            for (r in others) {
                val d = abs(chOf(r.frequency) - c)
                if (d < 5) t += (r.level + 100).coerceAtLeast(0) * (5 - d) / 5.0
            }
            return t
        }
        fun count(c: Int) = others.count { abs(chOf(it.frequency) - c) < 5 }
        fun level(sc: Double) = when { sc < 20 -> 3; sc < 80 -> 2; sc < 200 -> 1; else -> 0 }
        val names = arrayOf("ازدحام شديد", "ازدحام متوسط", "هادئة نسبيًا", "هادئة جدًا")

        if (myCh > 0) {
            val sc = score(myCh)
            line(chBox, "قناتك الحالية: $myCh — ${count(myCh)} شبكة مجاورة • ${names[level(sc)]}", colors[level(sc)])
        }
        val cands = intArrayOf(1, 6, 11)
        for (c in cands) {
            val sc = score(c)
            line(chBox, "قناة $c — ${count(c)} شبكة مجاورة • ${names[level(sc)]}", colors[level(sc)])
        }
        val best = cands.minByOrNull { score(it) } ?: 1
        val curScore = if (myCh > 0) score(myCh) else Double.MAX_VALUE
        val fine = myCh > 0 && (myCh == best || curScore <= score(best) * 1.2 + 10)
        if (fine) {
            line(chBox, "قناتك الحالية مناسبة — تغييرها لن يفيد كثيرًا ✓", colors[3])
        } else {
            val from = if (myCh > 0) " (بدل $myCh)" else ""
            line(chBox, "الأفضل لك: قناة $best$from", colors[3])
            line(chBox, "تغيير القناة يتم من الراوتر وليس من الهاتف: Wi-Fi ← Channel ← اختر $best ← احفظ. ويُفضّل عرض القناة 20 MHz.", 0xFF9AA4B5.toInt())
            line(chBox, "افتح صفحة الراوتر الآن  ◀", 0xFF4DA3FF.toInt()) { openRouter() }
        }
    }

    private fun openRouter() {
        val g = findGateway()
        if (g == null) {
            Toast.makeText(this, "لم أجد عنوان الراوتر — تأكد أنك متصل بالوايفاي", Toast.LENGTH_LONG).show()
            return
        }
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("http://$g"))) } catch (e: Exception) { }
    }

    // ───────────── اختبار DNS ─────────────

    private val dnsList = listOf(
        Dns("Cloudflare", "1.1.1.1", "one.one.one.one"),
        Dns("Google", "8.8.8.8", "dns.google"),
        Dns("Quad9", "9.9.9.9", "dns.quad9.net"),
        Dns("AdGuard (يحجب الإعلانات)", "94.140.14.14", "dns.adguard-dns.com"),
        Dns("OpenDNS", "208.67.222.222", null)
    )
    private val benchNames = arrayOf("google.com", "youtube.com", "facebook.com", "wikipedia.org", "amazon.com", "whatsapp.com")

    private fun systemDns(): String? {
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val n = cm.activeNetwork ?: return null
        val lp = cm.getLinkProperties(n) ?: return null
        for (d in lp.dnsServers) if (d is Inet4Address) return d.hostAddress
        return null
    }

    // استعلام DNS حقيقي عبر UDP؛ يرجع الزمن بالميلي ثانية أو -1
    private fun dnsQuery(server: String, domain: String, timeout: Int): Int {
        val id = (Math.random() * 65535).toInt()
        val out = java.io.ByteArrayOutputStream()
        out.write(id shr 8); out.write(id and 0xFF)
        out.write(0x01); out.write(0x00)
        out.write(0); out.write(1)
        for (i in 0 until 6) out.write(0)
        for (part in domain.split(".")) { out.write(part.length); out.write(part.toByteArray()) }
        out.write(0)
        out.write(0); out.write(1); out.write(0); out.write(1)
        val q = out.toByteArray()
        val t0 = SystemClock.elapsedRealtime()
        return try {
            java.net.DatagramSocket().use { sock ->
                sock.soTimeout = timeout
                sock.send(java.net.DatagramPacket(q, q.size, InetAddress.getByName(server), 53))
                val buf = ByteArray(512)
                sock.receive(java.net.DatagramPacket(buf, buf.size))
                val ms = (SystemClock.elapsedRealtime() - t0).toInt()
                val okId = (buf[0].toInt() and 0xFF) == (id shr 8) && (buf[1].toInt() and 0xFF) == (id and 0xFF)
                val rcode = buf[3].toInt() and 0x0F
                if (okId && rcode == 0) ms else -1
            }
        } catch (e: Exception) { -1 }
    }

    private fun benchDns() {
        if (dnsBusy) return
        dnsBusy = true
        dnsBox.removeAllViews()
        line(dnsBox, "جارٍ اختبار الخوادم… (حوالي 10 ثوانٍ)", 0xFF9AA4B5.toInt())
        val servers = ArrayList<Dns>(dnsList)
        val sys = systemDns()
        if (sys != null && dnsList.none { it.ip == sys }) servers.add(0, Dns("DNS الحالي (الراوتر/شركة الإنترنت)", sys, null))
        Thread {
            val results = java.util.Collections.synchronizedList(ArrayList<DnsRes>())
            val ts = servers.map { sv ->
                Thread {
                    val ok = ArrayList<Int>()
                    var fails = 0
                    for (n in benchNames) {
                        if (dnsQuery(sv.ip, n, 1200) < 0) { // المحاولة الأولى للإحماء فقط
                            fails++
                            if (fails >= 2 && ok.isEmpty()) break
                            continue
                        }
                        val r = dnsQuery(sv.ip, n, 1200)
                        if (r >= 0) ok.add(r) else fails++
                    }
                    ok.sort()
                    val med = if (ok.isEmpty()) -1 else ok[ok.size / 2]
                    results.add(DnsRes(sv.label, sv.host, med))
                }.also { it.start() }
            }
            for (t in ts) t.join(15000)
            val snapshot = ArrayList<DnsRes>(results)
            ui.post { showDns(snapshot, sys) }
        }.start()
    }

    private fun showDns(res: List<DnsRes>, sys: String?) {
        dnsBusy = false
        dnsBox.removeAllViews()
        val ok = res.filter { it.ms >= 0 }.sortedBy { it.ms }
        if (ok.isEmpty()) {
            line(dnsBox, "لم يستجب أي خادم — قد تكون الشبكة تحجب DNS الخارجي أو لا يوجد إنترنت.", colors[0])
            return
        }
        val cur = if (sys != null) res.firstOrNull { it.label.startsWith("DNS الحالي") } else null
        val best = ok.firstOrNull { it.host != null }
        val curMs = cur?.ms ?: -1
        if (best != null) {
            if (curMs >= 0 && best.ms >= curMs * 0.8 - 5) {
                line(dnsBox, "DNS الحالي جيد (${curMs} ms) — لا حاجة للتغيير ✓", colors[3])
            } else {
                val gain = if (curMs >= 0) " — أسرع من الحالي بـ ${curMs - best.ms} ms" else ""
                line(dnsBox, "الأفضل: ${best.label} (${best.ms} ms)$gain", colors[3])
            }
        }
        for (r in ok) {
            val tag = if (r.host == null) " • لا يدعم DNS الخاص" else ""
            line(dnsBox, "${r.label} — ${r.ms} ms$tag", Color.WHITE) { applyDns(r) }
        }
        for (r in res.filter { it.ms < 0 }) line(dnsBox, "${r.label} — لا يستجيب", colors[0])
        line(dnsBox, "اضغط على أي خادم لتطبيقه. القياس لأشهر المواقع (مخزّنة مؤقتًا).", 0xFF9AA4B5.toInt())
    }

    // أندرويد لا يسمح لأي تطبيق بتغيير DNS مباشرة؛ ننسخ الاسم ونفتح الإعدادات لتلصقه
    private fun applyDns(r: DnsRes) {
        val host = r.host
        if (host == null) {
            AlertDialog.Builder(this)
                .setTitle(r.label)
                .setMessage("هذا الخادم لا يدعم «DNS الخاص». لاستخدامه: إعدادات الوايفاي ← اضغط مطولًا على شبكتك ← تعديل ← خيارات متقدمة ← إعدادات IP: ثابت ← ثم اكتب عنوان DNS. أو غيّره من صفحة الراوتر ليستفيد جميع الأجهزة.")
                .setPositiveButton("حسنًا", null)
                .show()
            return
        }
        try {
            (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager)
                .setPrimaryClip(ClipData.newPlainText("dns", host))
        } catch (e: Exception) { }
        AlertDialog.Builder(this)
            .setTitle("تفعيل ${r.label}")
            .setMessage("نسخنا الاسم:\n$host\n\n١- اضغط «فتح الإعدادات»\n٢- ابحث في الإعدادات عن «DNS الخاص» (Private DNS)\n٣- اختر «اسم مضيف موفر DNS الخاص»\n٤- الصق الاسم واحفظ")
            .setPositiveButton("فتح الإعدادات") { _, _ ->
                try { startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS)) } catch (e: Exception) { }
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    // ───────────── مشاركة التقرير ─────────────

    private fun shareReport() {
        val sb = StringBuilder("تقرير جودة الوايفاي\n")
        sb.append(verdict.text).append("\n").append(diag.text).append("\n\n")
        for (r in rows) {
            sb.append("• ").append(r.title).append(": ").append(r.value.text)
            if (r.note.text.isNotEmpty()) sb.append(" — ").append(r.note.text)
            sb.append("\n")
        }
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, sb.toString())
        }
        startActivity(Intent.createChooser(i, "مشاركة التقرير"))
    }
}
